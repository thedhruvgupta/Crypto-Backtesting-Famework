"""
Market Cipher SR Strategy
Support and Resistance levels with pivot points
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class MarketCipherSRStrategy(BaseStrategy):
    """Market Cipher SR - Dynamic Support/Resistance Trading"""
    
    strategy_name = "Market Cipher SR"
    
    params = (
        # Pivot settings
        ('pivot_lookback', 20),
        ('sr_strength', 3),  # How many bars to confirm S/R
        ('zone_width', 0.002),  # 0.2% zone around S/R
        
        # Trend filter
        ('trend_period', 50),
        ('use_trend_filter', True),
        
        # Volume confirmation
        ('volume_multiplier', 1.5),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 5),
        ('stop_loss_pct', 1.5),
        ('take_profit_pct', 4.5),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Trend indicators
        self.ema_trend = bt.indicators.EMA(self.dataclose, period=self.params.trend_period)
        self.sma_trend = bt.indicators.SMA(self.dataclose, period=self.params.trend_period)
        
        # Pivot points
        self.pivot_high = bt.indicators.Highest(self.datahigh, period=self.params.pivot_lookback)
        self.pivot_low = bt.indicators.Lowest(self.datalow, period=self.params.pivot_lookback)
        
        # Calculate pivot point (traditional)
        self.pp = (self.datahigh + self.datalow + self.dataclose) / 3
        
        # Support and Resistance levels
        self.r1 = (2 * self.pp) - self.datalow
        self.s1 = (2 * self.pp) - self.datahigh
        self.r2 = self.pp + (self.datahigh - self.datalow)
        self.s2 = self.pp - (self.datahigh - self.datalow)
        self.r3 = self.datahigh + 2 * (self.pp - self.datalow)
        self.s3 = self.datalow - 2 * (self.datahigh - self.pp)
        
        # Volume analysis
        self.volume = self.datas[0].volume
        self.volume_sma = bt.indicators.SMA(self.volume, period=20)
        
        # RSI for confirmation
        self.rsi = bt.indicators.RSI(self.dataclose, period=14)
        
        # ATR for volatility-based zones
        self.atr = bt.indicators.ATR(self.datas[0], period=14)
        
        # Track S/R levels
        self.resistance_levels = []
        self.support_levels = []
        self.last_pivot_update = 0
        
        # Price action
        self.bullish_engulfing = self.dataclose[0] > self.dataopen[0] and self.dataclose[-1] < self.dataopen[-1]
        self.bearish_engulfing = self.dataclose[0] < self.dataopen[0] and self.dataclose[-1] > self.dataopen[-1]
        
    def update_sr_levels(self):
        """Update support and resistance levels dynamically"""
        
        # Update every N bars
        if len(self) - self.last_pivot_update < 10:
            return
            
        self.last_pivot_update = len(self)
        
        # Clear old levels
        self.resistance_levels = []
        self.support_levels = []
        
        # Find recent highs and lows
        lookback = min(100, len(self))
        for i in range(self.params.sr_strength, lookback - self.params.sr_strength):
            # Check for resistance (high point)
            is_resistance = True
            high_point = self.datahigh[-i]
            for j in range(1, self.params.sr_strength + 1):
                if self.datahigh[-i+j] > high_point or self.datahigh[-i-j] > high_point:
                    is_resistance = False
                    break
            if is_resistance:
                self.resistance_levels.append(high_point)
                
            # Check for support (low point)
            is_support = True
            low_point = self.datalow[-i]
            for j in range(1, self.params.sr_strength + 1):
                if self.datalow[-i+j] < low_point or self.datalow[-i-j] < low_point:
                    is_support = False
                    break
            if is_support:
                self.support_levels.append(low_point)
        
        # Keep only strongest levels (remove duplicates within zone)
        self.resistance_levels = self.consolidate_levels(self.resistance_levels)
        self.support_levels = self.consolidate_levels(self.support_levels)
    
    def consolidate_levels(self, levels):
        """Consolidate nearby levels into zones"""
        if not levels:
            return []
            
        consolidated = []
        levels.sort()
        
        for level in levels:
            if not consolidated:
                consolidated.append(level)
            elif abs(level - consolidated[-1]) / consolidated[-1] > self.params.zone_width:
                consolidated.append(level)
                
        return consolidated[-5:]  # Keep only 5 strongest levels
    
    def find_nearest_support(self, price):
        """Find nearest support level below current price"""
        supports_below = [s for s in self.support_levels if s < price]
        if supports_below:
            return max(supports_below)
        return self.s2[0]  # Fallback to pivot support
    
    def find_nearest_resistance(self, price):
        """Find nearest resistance level above current price"""
        resistances_above = [r for r in self.resistance_levels if r > price]
        if resistances_above:
            return min(resistances_above)
        return self.r2[0]  # Fallback to pivot resistance
    
    def buy_signal(self):
        """Buy at support levels with confirmation"""
        
        # Update S/R levels
        self.update_sr_levels()
        
        current_price = self.dataclose[0]
        
        # Find nearest support
        support = self.find_nearest_support(current_price)
        
        # Check if price is near support (within zone)
        near_support = abs(current_price - support) / support < self.params.zone_width
        
        # Check if price is at pivot support
        at_pivot_support = (
            abs(current_price - self.s1[0]) / self.s1[0] < self.params.zone_width or
            abs(current_price - self.s2[0]) / self.s2[0] < self.params.zone_width
        )
        
        # Trend filter
        if self.params.use_trend_filter:
            uptrend = current_price > self.ema_trend[0]
        else:
            uptrend = True
        
        # Volume confirmation
        volume_spike = self.volume[0] > self.volume_sma[0] * self.params.volume_multiplier
        
        # RSI confirmation (not oversold)
        rsi_confirm = self.rsi[0] < 70
        
        # Bullish price action
        bullish_candle = self.dataclose[0] > self.dataopen[0]
        higher_low = self.datalow[0] > self.datalow[-1]
        
        # Signal 1: Bounce from support with volume
        if (near_support or at_pivot_support) and volume_spike and bullish_candle and rsi_confirm:
            self.log(f'BUY: Support bounce at {support:.2f}')
            return True
        
        # Signal 2: Breakout above resistance
        resistance = self.find_nearest_resistance(current_price)
        if current_price > resistance and volume_spike and uptrend:
            self.log(f'BUY: Resistance breakout at {resistance:.2f}')
            return True
        
        # Signal 3: Pivot point bounce
        if abs(current_price - self.pp[0]) / self.pp[0] < self.params.zone_width and higher_low and uptrend:
            self.log('BUY: Pivot point bounce')
            return True
        
        # Signal 4: S3 extreme oversold
        if current_price <= self.s3[0] and self.rsi[0] < 30:
            self.log('BUY: Extreme oversold at S3')
            return True
            
        return False
    
    def sell_signal(self):
        """Sell at resistance levels with confirmation"""
        
        if not self.position:
            return False
        
        # Update S/R levels
        self.update_sr_levels()
        
        current_price = self.dataclose[0]
        
        # Find nearest resistance
        resistance = self.find_nearest_resistance(current_price)
        
        # Check if price is near resistance
        near_resistance = abs(current_price - resistance) / resistance < self.params.zone_width
        
        # Check if price is at pivot resistance
        at_pivot_resistance = (
            abs(current_price - self.r1[0]) / self.r1[0] < self.params.zone_width or
            abs(current_price - self.r2[0]) / self.r2[0] < self.params.zone_width
        )
        
        # RSI confirmation
        rsi_overbought = self.rsi[0] > 70
        
        # Bearish price action
        bearish_candle = self.dataclose[0] < self.dataopen[0]
        lower_high = self.datahigh[0] < self.datahigh[-1]
        
        # Signal 1: Resistance rejection
        if (near_resistance or at_pivot_resistance) and bearish_candle:
            self.log(f'SELL: Resistance rejection at {resistance:.2f}')
            return True
        
        # Signal 2: Support breakdown
        support = self.find_nearest_support(current_price)
        if current_price < support and self.volume[0] > self.volume_sma[0]:
            self.log(f'SELL: Support breakdown at {support:.2f}')
            return True
        
        # Signal 3: R3 extreme overbought
        if current_price >= self.r3[0] or rsi_overbought:
            self.log('SELL: Extreme overbought at R3')
            return True
        
        # Signal 4: Pivot point rejection
        if abs(current_price - self.pp[0]) / self.pp[0] < self.params.zone_width and lower_high:
            self.log('SELL: Pivot point rejection')
            return True
            
        return False
