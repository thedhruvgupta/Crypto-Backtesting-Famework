"""
MACD Strategy with Histogram Confirmation
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy

class MACDStrategy(BaseStrategy):
    """MACD Strategy with histogram and trend confirmation"""
    
    strategy_name = "MACD Advanced"
    
    params = (
        ('fast_ema', 12),
        ('slow_ema', 26),
        ('signal_ema', 9),
        ('use_histogram', True),
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 1),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # MACD indicator
        self.macd = bt.indicators.MACD(
            self.dataclose,
            period_me1=self.params.fast_ema,
            period_me2=self.params.slow_ema,
            period_signal=self.params.signal_ema
        )
        
        # MACD crossover
        self.macd_crossover = bt.indicators.CrossOver(self.macd.macd, self.macd.signal)
        
        # Histogram (MACD - Signal)
        self.histogram = self.macd.macd - self.macd.signal
        
        # Trend filter (50 EMA)
        self.trend = bt.indicators.EMA(self.dataclose, period=50)
        
    def buy_signal(self):
        """Buy when MACD crosses above signal with positive histogram"""
        if self.params.use_histogram:
            return (self.macd_crossover > 0 and 
                    self.histogram[0] > 0 and
                    self.dataclose[0] > self.trend[0])  # Price above trend
        else:
            return self.macd_crossover > 0
    
    def sell_signal(self):
        """Sell when MACD crosses below signal"""
        return self.macd_crossover < 0 or self.histogram[0] < self.histogram[-1] * 0.5  # Histogram weakening
