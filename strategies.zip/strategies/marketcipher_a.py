"""
Market Cipher A Strategy
The original Market Cipher with wave momentum and VWAP deviation
"""

import backtrader as bt
import sys
import os
import math

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class MarketCipherAStrategy(BaseStrategy):
    """Market Cipher A - Wave Momentum with VWAP Deviation"""
    
    strategy_name = "Market Cipher A"
    
    params = (
        # Wave settings
        ('momentum_length', 10),
        ('wave_period', 21),
        ('vwap_period', 20),
        
        # Deviation bands
        ('vwap_dev1', 1.0),
        ('vwap_dev2', 2.0),
        ('vwap_dev3', 3.0),
        
        # Signal thresholds
        ('momentum_threshold', 0),
        ('wave_oversold', -2.0),
        ('wave_overbought', 2.0),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 2.5),
        ('leverage', 8),
        ('stop_loss_pct', 2.5),
        ('take_profit_pct', 7.5),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Calculate VWAP (Volume Weighted Average Price)
        typical_price = (self.datahigh + self.datalow + self.dataclose) / 3
        
        # Cumulative volume and price*volume
        cum_volume = bt.indicators.CumSum(self.datas[0].volume)
        cum_pv = bt.indicators.CumSum(typical_price * self.datas[0].volume)
        
        # VWAP
        self.vwap = cum_pv / bt.If(cum_volume > 0, cum_volume, 1)
        
        # VWAP Deviation Bands
        squared_diff = (typical_price - self.vwap) ** 2
        variance = bt.indicators.SMA(squared_diff, period=self.params.vwap_period)
        self.vwap_std = bt.If(variance > 0, variance ** 0.5, 0.001)
        
        # Deviation bands
        self.vwap_upper1 = self.vwap + (self.vwap_std * self.params.vwap_dev1)
        self.vwap_lower1 = self.vwap - (self.vwap_std * self.params.vwap_dev1)
        self.vwap_upper2 = self.vwap + (self.vwap_std * self.params.vwap_dev2)
        self.vwap_lower2 = self.vwap - (self.vwap_std * self.params.vwap_dev2)
        self.vwap_upper3 = self.vwap + (self.vwap_std * self.params.vwap_dev3)
        self.vwap_lower3 = self.vwap - (self.vwap_std * self.params.vwap_dev3)
        
        # Wave Momentum Oscillator
        self.momentum = bt.indicators.Momentum(self.dataclose, period=self.params.momentum_length)
        self.wave = bt.indicators.EMA(self.momentum - 100, period=self.params.wave_period)
        
        # Blue Wave (smoother version)
        self.blue_wave = bt.indicators.SMA(self.wave, period=3)
        
        # Market Cipher Momentum
        highest = bt.indicators.Highest(self.datahigh, period=self.params.wave_period)
        lowest = bt.indicators.Lowest(self.datalow, period=self.params.wave_period)
        self.mc_momentum = (self.dataclose - lowest) / bt.If((highest - lowest) > 0, highest - lowest, 0.001) * 100
        
        # Volume Flow
        self.volume_sma = bt.indicators.SMA(self.datas[0].volume, period=20)
        self.volume_flow = self.datas[0].volume / bt.If(self.volume_sma > 0, self.volume_sma, 1)
        
        # Track zones
        self.in_buy_zone = False
        self.in_sell_zone = False
        
    def buy_signal(self):
        """Generate buy signals based on Market Cipher A"""
        
        # Signal 1: Price at lower VWAP deviation bands
        vwap_oversold = (
            self.dataclose[0] <= self.vwap_lower2[0] and
            self.dataclose[0] > self.vwap_lower3[0]
        )
        
        # Signal 2: Wave momentum reversal
        wave_buy = (
            self.wave[0] < self.params.wave_oversold and
            self.wave[0] > self.wave[-1] and  # Starting to turn up
            self.blue_wave[0] > self.blue_wave[-1]
        )
        
        # Signal 3: Momentum cross above threshold
        momentum_buy = (
            self.momentum[0] > 100 + self.params.momentum_threshold and
            self.momentum[-1] <= 100 + self.params.momentum_threshold and
            self.dataclose[0] < self.vwap[0]  # Below VWAP
        )
        
        # Signal 4: Extreme oversold bounce
        extreme_buy = (
            self.dataclose[0] <= self.vwap_lower3[0] and
            self.mc_momentum[0] < 20 and
            self.volume_flow[0] > 1.5  # High volume
        )
        
        # Signal 5: VWAP reclaim
        vwap_reclaim = (
            self.dataclose[0] > self.vwap[0] and
            self.dataclose[-1] <= self.vwap[-1] and
            self.wave[0] > self.params.wave_oversold and
            self.momentum[0] > 100
        )
        
        # Signal 6: Blue wave divergence
        blue_divergence = (
            self.blue_wave[0] > self.blue_wave[-1] and
            self.blue_wave[0] < -1 and
            self.dataclose[0] > self.datalow[-5:].min()  # Higher low
        )
        
        if extreme_buy:
            self.log('BUY: Extreme oversold at 3rd deviation')
            self.in_buy_zone = True
            return True
        elif vwap_oversold and wave_buy:
            self.log('BUY: VWAP oversold with wave reversal')
            self.in_buy_zone = True
            return True
        elif momentum_buy:
            self.log('BUY: Momentum cross with VWAP support')
            self.in_buy_zone = True
            return True
        elif vwap_reclaim:
            self.log('BUY: VWAP reclaim')
            self.in_buy_zone = True
            return True
        elif blue_divergence:
            self.log('BUY: Blue wave divergence')
            self.in_buy_zone = True
            return True
            
        return False
    
    def sell_signal(self):
        """Generate sell signals based on Market Cipher A"""
        
        if not self.position:
            return False
        
        # Signal 1: Price at upper VWAP deviation bands
        vwap_overbought = (
            self.dataclose[0] >= self.vwap_upper2[0]
        )
        
        # Signal 2: Wave momentum reversal
        wave_sell = (
            self.wave[0] > self.params.wave_overbought and
            self.wave[0] < self.wave[-1]  # Starting to turn down
        )
        
        # Signal 3: Momentum cross below threshold
        momentum_sell = (
            self.momentum[0] < 100 - self.params.momentum_threshold and
            self.momentum[-1] >= 100 - self.params.momentum_threshold
        )
        
        # Signal 4: Extreme overbought
        extreme_sell = (
            self.dataclose[0] >= self.vwap_upper3[0] or
            self.mc_momentum[0] > 80
        )
        
        # Signal 5: VWAP rejection
        vwap_rejection = (
            self.dataclose[0] < self.vwap[0] and
            self.dataclose[-1] >= self.vwap[-1] and
            self.wave[0] < 0
        )
        
        # Signal 6: Blue wave weakness
        blue_weakness = (
            self.blue_wave[0] < self.blue_wave[-1] and
            self.blue_wave[0] > 1 and
            self.in_buy_zone  # Was in buy zone
        )
        
        if extreme_sell:
            self.log('SELL: Extreme overbought at 3rd deviation')
            self.in_buy_zone = False
            return True
        elif vwap_overbought and wave_sell:
            self.log('SELL: VWAP overbought with wave reversal')
            self.in_buy_zone = False
            return True
        elif momentum_sell and self.dataclose[0] > self.entry_price:
            self.log('SELL: Momentum cross in profit')
            self.in_buy_zone = False
            return True
        elif vwap_rejection:
            self.log('SELL: VWAP rejection')
            self.in_buy_zone = False
            return True
        elif blue_weakness:
            self.log('SELL: Blue wave weakness')
            self.in_buy_zone = False
            return True
            
        return False
