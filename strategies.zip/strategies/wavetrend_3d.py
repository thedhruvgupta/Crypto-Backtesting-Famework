"""
WaveTrend 3D Strategy
Multi-timeframe wave analysis with 3D market structure
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class WaveTrend3DStrategy(BaseStrategy):
    """WaveTrend 3D - Multi-dimensional market analysis"""
    
    strategy_name = "WaveTrend 3D"
    
    params = (
        # WaveTrend settings for 3 dimensions
        ('wt1_channel', 9),
        ('wt1_average', 12),
        ('wt2_channel', 21),
        ('wt2_average', 27),
        ('wt3_channel', 50),
        ('wt3_average', 60),
        
        # Thresholds
        ('oversold_level', -60),
        ('overbought_level', 60),
        ('extreme_level', 80),
        
        # Market structure
        ('structure_period', 50),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 2.5),
        ('leverage', 12),
        ('stop_loss_pct', 2.5),
        ('take_profit_pct', 7.5),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # HLC3
        self.hlc3 = (self.datahigh + self.datalow + self.dataclose) / 3
        
        # WaveTrend Dimension 1 (Fast)
        self.esa1 = bt.indicators.EMA(self.hlc3, period=self.params.wt1_channel)
        self.de1 = bt.indicators.EMA(abs(self.hlc3 - self.esa1), period=self.params.wt1_channel)
        self.ci1 = (self.hlc3 - self.esa1) / bt.If(self.de1 > 0, 0.015 * self.de1, 0.0001)
        self.wt1_fast = bt.indicators.EMA(self.ci1, period=self.params.wt1_average)
        self.wt1_slow = bt.indicators.SMA(self.wt1_fast, period=3)
        
        # WaveTrend Dimension 2 (Medium)
        self.esa2 = bt.indicators.EMA(self.hlc3, period=self.params.wt2_channel)
        self.de2 = bt.indicators.EMA(abs(self.hlc3 - self.esa2), period=self.params.wt2_channel)
        self.ci2 = (self.hlc3 - self.esa2) / bt.If(self.de2 > 0, 0.015 * self.de2, 0.0001)
        self.wt2_fast = bt.indicators.EMA(self.ci2, period=self.params.wt2_average)
        self.wt2_slow = bt.indicators.SMA(self.wt2_fast, period=5)
        
        # WaveTrend Dimension 3 (Slow)
        self.esa3 = bt.indicators.EMA(self.hlc3, period=self.params.wt3_channel)
        self.de3 = bt.indicators.EMA(abs(self.hlc3 - self.esa3), period=self.params.wt3_channel)
        self.ci3 = (self.hlc3 - self.esa3) / bt.If(self.de3 > 0, 0.015 * self.de3, 0.0001)
        self.wt3_fast = bt.indicators.EMA(self.ci3, period=self.params.wt3_average)
        self.wt3_slow = bt.indicators.SMA(self.wt3_fast, period=7)
        
        # Market Structure
        self.market_high = bt.indicators.Highest(self.datahigh, period=self.params.structure_period)
        self.market_low = bt.indicators.Lowest(self.datalow, period=self.params.structure_period)
        self.market_mid = (self.market_high + self.market_low) / 2
        
        # 3D Composite Score
        self.composite_wt = (self.wt1_fast + self.wt2_fast + self.wt3_fast) / 3
        
        # Momentum
        self.momentum = bt.indicators.Momentum(self.dataclose, period=14)
        
        # Volume
        self.volume_sma = bt.indicators.SMA(self.datas[0].volume, period=20)
        
        # RSI
        self.rsi = bt.indicators.RSI(self.dataclose, period=14)
        
    def analyze_3d_structure(self):
        """Analyze multi-dimensional market structure"""
        
        # Dimension alignment
        d1_bullish = self.wt1_fast[0] > self.wt1_slow[0]
        d2_bullish = self.wt2_fast[0] > self.wt2_slow[0]
        d3_bullish = self.wt3_fast[0] > self.wt3_slow[0]
        
        # Count bullish dimensions
        bullish_count = sum([d1_bullish, d2_bullish, d3_bullish])
        
        # Market position
        above_mid = self.dataclose[0] > self.market_mid[0]
        
        # Trend strength
        trend_strength = abs(self.composite_wt[0]) / 100
        
        return {
            'bullish_dimensions': bullish_count,
            'above_market_mid': above_mid,
            'trend_strength': trend_strength,
            'd1_bullish': d1_bullish,
            'd2_bullish': d2_bullish,
            'd3_bullish': d3_bullish
        }
    
    def buy_signal(self):
        """3D buy signals"""
        
        structure = self.analyze_3d_structure()
        
        # Signal 1: 3D Oversold Confluence
        d1_oversold = self.wt1_fast[0] < self.params.oversold_level
        d2_oversold = self.wt2_fast[0] < self.params.oversold_level
        d3_oversold = self.wt3_fast[0] < self.params.oversold_level * 0.7
        
        oversold_confluence = sum([d1_oversold, d2_oversold, d3_oversold]) >= 2
        
        if oversold_confluence and self.wt1_fast[0] > self.wt1_fast[-1]:
            self.log('BUY: 3D Oversold Confluence')
            return True
        
        # Signal 2: Dimension Alignment
        if structure['bullish_dimensions'] == 3 and self.composite_wt[0] > self.composite_wt[-1]:
            self.log('BUY: All 3 Dimensions Aligned Bullish')
            return True
        
        # Signal 3: Fast Dimension Cross with Support
        d1_cross_up = (
            self.wt1_fast[-1] < self.wt1_slow[-1] and
            self.wt1_fast[0] > self.wt1_slow[0]
        )
        
        if d1_cross_up and structure['d2_bullish'] and not structure['above_market_mid']:
            self.log('BUY: Fast Dimension Cross with Structure Support')
            return True
        
        # Signal 4: Extreme Oversold Bounce
        if self.composite_wt[0] < -self.params.extreme_level and self.rsi[0] < 30:
            self.log('BUY: Extreme 3D Oversold')
            return True
        
        # Signal 5: Momentum Divergence
        price_lower = self.dataclose[0] < self.dataclose[-10]
        wt_higher = self.composite_wt[0] > self.composite_wt[-10]
        
        if price_lower and wt_higher and self.composite_wt[0] < 0:
            self.log('BUY: 3D Bullish Divergence')
            return True
        
        # Signal 6: Volume Surge at Support
        volume_surge = self.datas[0].volume[0] > self.volume_sma[0] * 2
        at_support = self.dataclose[0] <= self.market_low[0] * 1.02
        
        if volume_surge and at_support and structure['bullish_dimensions'] >= 1:
            self.log('BUY: Volume Surge at Market Support')
            return True
        
        return False
    
    def sell_signal(self):
        """3D sell signals"""
        
        if not self.position:
            return False
        
        structure = self.analyze_3d_structure()
        
        # Signal 1: 3D Overbought Confluence
        d1_overbought = self.wt1_fast[0] > self.params.overbought_level
        d2_overbought = self.wt2_fast[0] > self.params.overbought_level
        d3_overbought = self.wt3_fast[0] > self.params.overbought_level * 0.7
        
        overbought_confluence = sum([d1_overbought, d2_overbought, d3_overbought]) >= 2
        
        if overbought_confluence and self.wt1_fast[0] < self.wt1_fast[-1]:
            self.log('SELL: 3D Overbought Confluence')
            return True
        
        # Signal 2: Dimension Misalignment
        if structure['bullish_dimensions'] == 0:
            self.log('SELL: All 3 Dimensions Turned Bearish')
            return True
        
        # Signal 3: Fast Dimension Cross Down
        d1_cross_down = (
            self.wt1_fast[-1] > self.wt1_slow[-1] and
            self.wt1_fast[0] < self.wt1_slow[0]
        )
        
        if d1_cross_down and not structure['d2_bullish']:
            self.log('SELL: Fast Dimension Cross with Structure Resistance')
            return True
        
        # Signal 4: Extreme Overbought
        if self.composite_wt[0] > self.params.extreme_level:
            self.log('SELL: Extreme 3D Overbought')
            return True
        
        # Signal 5: Momentum Divergence
        price_higher = self.dataclose[0] > self.dataclose[-10]
        wt_lower = self.composite_wt[0] < self.composite_wt[-10]
        
        if price_higher and wt_lower and self.composite_wt[0] > 0:
            self.log('SELL: 3D Bearish Divergence')
            return True
        
        # Signal 6: Market Structure Break
        if self.dataclose[0] < self.market_mid[0] and structure['bullish_dimensions'] <= 1:
            self.log('SELL: Market Structure Break')
            return True
        
        return False
