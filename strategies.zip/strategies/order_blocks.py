"""
Order Block Strategy
Smart Money Concepts - Institutional order flow detection
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class OrderBlockStrategy(BaseStrategy):
    """Order Block - Smart Money Concepts Trading"""
    
    strategy_name = "Order Blocks SMC"
    
    params = (
        # Order block detection
        ('ob_lookback', 20),
        ('ob_threshold', 0.003),  # 0.3% move to qualify
        ('ob_volume_mult', 1.5),
        
        # Fair Value Gap
        ('fvg_enabled', True),
        ('fvg_min_size', 0.001),  # 0.1% minimum gap
        
        # Liquidity
        ('liquidity_lookback', 50),
        ('sweep_threshold', 0.002),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 10),
        ('stop_loss_pct', 1.5),
        ('take_profit_pct', 4.5),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Market structure
        self.swing_high = bt.indicators.Highest(self.datahigh, period=self.params.liquidity_lookback)
        self.swing_low = bt.indicators.Lowest(self.datalow, period=self.params.liquidity_lookback)
        
        # Volume
        self.volume = self.datas[0].volume
        self.volume_sma = bt.indicators.SMA(self.volume, period=20)
        
        # ATR for volatility
        self.atr = bt.indicators.ATR(self.datas[0], period=14)
        
        # Trend
        self.ema_fast = bt.indicators.EMA(self.dataclose, period=21)
        self.ema_slow = bt.indicators.EMA(self.dataclose, period=50)
        
        # RSI
        self.rsi = bt.indicators.RSI(self.dataclose, period=14)
        
        # Track order blocks
        self.bullish_obs = []
        self.bearish_obs = []
        
        # Track fair value gaps
        self.bullish_fvgs = []
        self.bearish_fvgs = []
        
        # Track liquidity sweeps
        self.last_sweep = None
        
    def identify_order_block(self):
        """Identify bullish and bearish order blocks"""
        
        if len(self) < self.params.ob_lookback:
            return
        
        # Bullish order block: Last bearish candle before bullish move
        for i in range(2, min(self.params.ob_lookback, len(self))):
            # Check if we had a bearish candle
            was_bearish = self.dataclose[-i] < self.dataopen[-i]
            
            # Check if followed by bullish move
            move_up = (self.dataclose[0] - self.dataclose[-i]) / self.dataclose[-i]
            
            # Check volume
            high_volume = self.volume[-i] > self.volume_sma[-i] * self.params.ob_volume_mult
            
            if was_bearish and move_up > self.params.ob_threshold and high_volume:
                # Found bullish order block
                ob = {
                    'high': self.datahigh[-i],
                    'low': self.datalow[-i],
                    'time': len(self) - i,
                    'volume': self.volume[-i]
                }
                
                # Check if not duplicate
                duplicate = False
                for existing_ob in self.bullish_obs:
                    if abs(existing_ob['low'] - ob['low']) / ob['low'] < 0.001:
                        duplicate = True
                        break
                
                if not duplicate:
                    self.bullish_obs.append(ob)
                    # Keep only recent order blocks
                    if len(self.bullish_obs) > 10:
                        self.bullish_obs.pop(0)
                break
        
        # Bearish order block: Last bullish candle before bearish move
        for i in range(2, min(self.params.ob_lookback, len(self))):
            # Check if we had a bullish candle
            was_bullish = self.dataclose[-i] > self.dataopen[-i]
            
            # Check if followed by bearish move
            move_down = (self.dataclose[-i] - self.dataclose[0]) / self.dataclose[-i]
            
            # Check volume
            high_volume = self.volume[-i] > self.volume_sma[-i] * self.params.ob_volume_mult
            
            if was_bullish and move_down > self.params.ob_threshold and high_volume:
                # Found bearish order block
                ob = {
                    'high': self.datahigh[-i],
                    'low': self.datalow[-i],
                    'time': len(self) - i,
                    'volume': self.volume[-i]
                }
                
                # Check if not duplicate
                duplicate = False
                for existing_ob in self.bearish_obs:
                    if abs(existing_ob['high'] - ob['high']) / ob['high'] < 0.001:
                        duplicate = True
                        break
                
                if not duplicate:
                    self.bearish_obs.append(ob)
                    # Keep only recent order blocks
                    if len(self.bearish_obs) > 10:
                        self.bearish_obs.pop(0)
                break
    
    def identify_fvg(self):
        """Identify Fair Value Gaps (imbalances)"""
        
        if not self.params.fvg_enabled or len(self) < 3:
            return
        
        # Bullish FVG: Gap between candle 3 low and candle 1 high
        gap_up = self.datalow[0] - self.datahigh[-2]
        if gap_up > self.dataclose[-1] * self.params.fvg_min_size:
            fvg = {
                'high': self.datalow[0],
                'low': self.datahigh[-2],
                'time': len(self)
            }
            self.bullish_fvgs.append(fvg)
            if len(self.bullish_fvgs) > 5:
                self.bullish_fvgs.pop(0)
        
        # Bearish FVG: Gap between candle 1 low and candle 3 high
        gap_down = self.datalow[-2] - self.datahigh[0]
        if gap_down > self.dataclose[-1] * self.params.fvg_min_size:
            fvg = {
                'high': self.datalow[-2],
                'low': self.datahigh[0],
                'time': len(self)
            }
            self.bearish_fvgs.append(fvg)
            if len(self.bearish_fvgs) > 5:
                self.bearish_fvgs.pop(0)
    
    def detect_liquidity_sweep(self):
        """Detect liquidity sweeps (stop hunts)"""
        
        # Detect sweep of highs
        if self.datahigh[0] > self.swing_high[-1] * (1 + self.params.sweep_threshold):
            if self.dataclose[0] < self.swing_high[-1]:
                self.last_sweep = {'type': 'high_sweep', 'time': len(self)}
                return 'high_sweep'
        
        # Detect sweep of lows
        if self.datalow[0] < self.swing_low[-1] * (1 - self.params.sweep_threshold):
            if self.dataclose[0] > self.swing_low[-1]:
                self.last_sweep = {'type': 'low_sweep', 'time': len(self)}
                return 'low_sweep'
        
        return None
    
    def check_ob_test(self, price):
        """Check if price is testing an order block"""
        
        # Check bullish order blocks
        for ob in self.bullish_obs:
            if ob['low'] <= price <= ob['high']:
                return 'bullish_ob'
        
        # Check bearish order blocks
        for ob in self.bearish_obs:
            if ob['low'] <= price <= ob['high']:
                return 'bearish_ob'
        
        return None
    
    def check_fvg_test(self, price):
        """Check if price is testing a Fair Value Gap"""
        
        # Check bullish FVGs
        for fvg in self.bullish_fvgs:
            if fvg['low'] <= price <= fvg['high']:
                return 'bullish_fvg'
        
        # Check bearish FVGs
        for fvg in self.bearish_fvgs:
            if fvg['low'] <= price <= fvg['high']:
                return 'bearish_fvg'
        
        return None
    
    def buy_signal(self):
        """Generate buy signals based on Smart Money Concepts"""
        
        # Update order blocks and FVGs
        self.identify_order_block()
        self.identify_fvg()
        sweep = self.detect_liquidity_sweep()
        
        current_price = self.dataclose[0]
        
        # Signal 1: Bullish order block test
        ob_test = self.check_ob_test(current_price)
        if ob_test == 'bullish_ob':
            # Confirm with trend and volume
            if self.ema_fast[0] > self.ema_slow[0] and self.volume[0] > self.volume_sma[0]:
                self.log('BUY: Bullish Order Block Test')
                return True
        
        # Signal 2: Bullish FVG fill
        fvg_test = self.check_fvg_test(current_price)
        if fvg_test == 'bullish_fvg':
            # Confirm with momentum
            if self.rsi[0] > 40 and self.dataclose[0] > self.dataopen[0]:
                self.log('BUY: Bullish Fair Value Gap Fill')
                return True
        
        # Signal 3: Liquidity sweep reversal
        if sweep == 'low_sweep':
            self.log('BUY: Liquidity Sweep Reversal')
            return True
        
        # Signal 4: Recent low sweep with order block
        if self.last_sweep and self.last_sweep['type'] == 'low_sweep':
            if len(self) - self.last_sweep['time'] < 5:
                if ob_test == 'bullish_ob':
                    self.log('BUY: Sweep + Order Block Confluence')
                    return True
        
        # Signal 5: Break of structure with retest
        if len(self) > 2:
            # Check for break of structure
            if self.datahigh[0] > self.swing_high[-10] and self.dataclose[-1] < self.swing_high[-10]:
                # Retest of broken level
                if abs(self.dataclose[0] - self.swing_high[-10]) / self.swing_high[-10] < 0.003:
                    self.log('BUY: Break of Structure Retest')
                    return True
        
        return False
    
    def sell_signal(self):
        """Generate sell signals based on Smart Money Concepts"""
        
        if not self.position:
            return False
        
        current_price = self.dataclose[0]
        
        # Update structures
        sweep = self.detect_liquidity_sweep()
        
        # Signal 1: Bearish order block test
        ob_test = self.check_ob_test(current_price)
        if ob_test == 'bearish_ob':
            self.log('SELL: Bearish Order Block Test')
            return True
        
        # Signal 2: Bearish FVG fill
        fvg_test = self.check_fvg_test(current_price)
        if fvg_test == 'bearish_fvg':
            self.log('SELL: Bearish Fair Value Gap Fill')
            return True
        
        # Signal 3: Liquidity sweep
        if sweep == 'high_sweep':
            self.log('SELL: Liquidity Sweep at Highs')
            return True
        
        # Signal 4: Break of structure
        if self.datalow[0] < self.swing_low[-10]:
            self.log('SELL: Break of Structure')
            return True
        
        # Signal 5: Loss of order block support
        if self.entry_price:
            # Check if we entered on order block
            for ob in self.bullish_obs:
                if abs(self.entry_price - ob['low']) / ob['low'] < 0.005:
                    # Check if order block is broken
                    if self.dataclose[0] < ob['low'] * 0.995:
                        self.log('SELL: Order Block Support Lost')
                        return True
        
        return False
