"""
SMA Crossover Strategy
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy

class SMAStrategy(BaseStrategy):
    """SMA Crossover Strategy with optimized parameters"""
    
    strategy_name = "SMA Crossover"
    
    params = (
        ('fast_period', 20),
        ('slow_period', 50),
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 1),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # SMA indicators
        self.sma_fast = bt.indicators.SMA(self.dataclose, period=self.params.fast_period)
        self.sma_slow = bt.indicators.SMA(self.dataclose, period=self.params.slow_period)
        
        # Crossover signal
        self.crossover = bt.indicators.CrossOver(self.sma_fast, self.sma_slow)
        
    def buy_signal(self):
        """Generate buy signal when fast SMA crosses above slow SMA"""
        return self.crossover > 0
    
    def sell_signal(self):
        """Generate sell signal when fast SMA crosses below slow SMA"""
        return self.crossover < 0
