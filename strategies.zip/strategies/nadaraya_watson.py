"""
Nadaraya-Watson Envelope Strategy
Machine learning kernel regression for price prediction
"""

import backtrader as bt
import sys
import os
import numpy as np

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class NadarayaWatsonStrategy(BaseStrategy):
    """Nadaraya-Watson Envelope - ML-based price prediction"""
    
    strategy_name = "Nadaraya-Watson ML"
    
    params = (
        # Kernel parameters
        ('lookback', 50),  # Lookback window
        ('bandwidth', 8.0),  # Kernel bandwidth
        ('envelope_mult', 2.0),  # Envelope multiplier
        
        # Signal parameters
        ('use_atr_bands', True),
        ('atr_period', 14),
        ('atr_multiplier', 2.0),
        
        # Confirmation indicators
        ('rsi_period', 14),
        ('volume_period', 20),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 7),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # ATR for adaptive bands
        self.atr = bt.indicators.ATR(self.datas[0], period=self.params.atr_period)
        
        # RSI for confirmation
        self.rsi = bt.indicators.RSI(self.dataclose, period=self.params.rsi_period)
        
        # Volume
        self.volume_sma = bt.indicators.SMA(self.datas[0].volume, period=self.params.volume_period)
        
        # Store kernel regression values
        self.nw_line = []
        self.upper_envelope = []
        self.lower_envelope = []
        
        # Trend detection
        self.ema_fast = bt.indicators.EMA(self.dataclose, period=20)
        self.ema_slow = bt.indicators.EMA(self.dataclose, period=50)
        
        # Signal flags
        self.cross_above = False
        self.cross_below = False
        
    def calculate_kernel_regression(self):
        """Calculate Nadaraya-Watson kernel regression"""
        
        if len(self) < self.params.lookback:
            return 0, 0, 0
        
        # Get recent prices
        prices = [self.dataclose[-i] for i in range(self.params.lookback)]
        prices.reverse()
        
        # Current point
        x0 = self.params.lookback - 1
        
        # Calculate weights using Gaussian kernel
        weights = []
        weighted_sum = 0
        weight_sum = 0
        
        for i in range(self.params.lookback):
            # Distance from current point
            distance = abs(i - x0)
            
            # Gaussian kernel weight
            weight = np.exp(-(distance ** 2) / (2 * self.params.bandwidth ** 2))
            weights.append(weight)
            
            # Weighted sum
            weighted_sum += prices[i] * weight
            weight_sum += weight
        
        # Kernel regression estimate
        if weight_sum > 0:
            nw_estimate = weighted_sum / weight_sum
        else:
            nw_estimate = self.dataclose[0]
        
        # Calculate envelope based on local variance
        if self.params.use_atr_bands:
            # Use ATR for adaptive bands
            envelope_width = self.atr[0] * self.params.atr_multiplier
        else:
            # Calculate local variance
            variance = 0
            for i in range(self.params.lookback):
                variance += weights[i] * (prices[i] - nw_estimate) ** 2
            
            if weight_sum > 0:
                variance = variance / weight_sum
                std_dev = np.sqrt(variance)
                envelope_width = std_dev * self.params.envelope_mult
            else:
                envelope_width = self.atr[0] * 2
        
        upper_envelope = nw_estimate + envelope_width
        lower_envelope = nw_estimate - envelope_width
        
        return nw_estimate, upper_envelope, lower_envelope
    
    def detect_crossovers(self):
        """Detect price crossovers with NW line"""
        
        if len(self.nw_line) < 2:
            return
        
        current_price = self.dataclose[0]
        prev_price = self.dataclose[-1]
        current_nw = self.nw_line[-1]
        prev_nw = self.nw_line[-2] if len(self.nw_line) >= 2 else current_nw
        
        # Detect crossovers
        self.cross_above = prev_price <= prev_nw and current_price > current_nw
        self.cross_below = prev_price >= prev_nw and current_price < current_nw
    
    def buy_signal(self):
        """Generate buy signals using Nadaraya-Watson"""
        
        # Calculate kernel regression
        nw_estimate, upper_env, lower_env = self.calculate_kernel_regression()
        
        # Store values
        self.nw_line.append(nw_estimate)
        self.upper_envelope.append(upper_env)
        self.lower_envelope.append(lower_env)
        
        # Keep only recent values
        if len(self.nw_line) > 100:
            self.nw_line.pop(0)
            self.upper_envelope.pop(0)
            self.lower_envelope.pop(0)
        
        # Detect crossovers
        self.detect_crossovers()
        
        current_price = self.dataclose[0]
        
        # Signal 1: Touch lower envelope with RSI oversold
        at_lower_envelope = (
            current_price <= lower_env and
            current_price >= lower_env * 0.998  # Within 0.2% of envelope
        )
        
        if at_lower_envelope and self.rsi[0] < 40:
            self.log('BUY: Lower envelope touch with RSI oversold')
            return True
        
        # Signal 2: Cross above NW line with momentum
        if self.cross_above and self.ema_fast[0] > self.ema_slow[0]:
            self.log('BUY: Cross above NW line with uptrend')
            return True
        
        # Signal 3: Bounce from NW line in uptrend
        near_nw = abs(current_price - nw_estimate) / nw_estimate < 0.005
        if near_nw and current_price > nw_estimate and self.ema_fast[0] > self.ema_slow[0]:
            self.log('BUY: Bounce from NW line support')
            return True
        
        # Signal 4: Extreme oversold below lower envelope
        if current_price < lower_env * 0.995 and self.rsi[0] < 30:
            self.log('BUY: Extreme oversold below envelope')
            return True
        
        # Signal 5: Envelope squeeze breakout
        envelope_width = upper_env - lower_env
        avg_width = np.mean([self.upper_envelope[i] - self.lower_envelope[i] 
                            for i in range(min(20, len(self.upper_envelope)))])
        
        if envelope_width < avg_width * 0.7 and current_price > nw_estimate:
            self.log('BUY: Envelope squeeze breakout')
            return True
        
        return False
    
    def sell_signal(self):
        """Generate sell signals using Nadaraya-Watson"""
        
        if not self.position or len(self.nw_line) < 1:
            return False
        
        current_price = self.dataclose[0]
        nw_estimate = self.nw_line[-1]
        upper_env = self.upper_envelope[-1]
        lower_env = self.lower_envelope[-1]
        
        # Detect crossovers
        self.detect_crossovers()
        
        # Signal 1: Touch upper envelope with RSI overbought
        at_upper_envelope = (
            current_price >= upper_env * 0.998 and
            current_price <= upper_env
        )
        
        if at_upper_envelope and self.rsi[0] > 60:
            self.log('SELL: Upper envelope touch with RSI overbought')
            return True
        
        # Signal 2: Cross below NW line
        if self.cross_below:
            self.log('SELL: Cross below NW line')
            return True
        
        # Signal 3: Rejection from NW line in downtrend
        near_nw = abs(current_price - nw_estimate) / nw_estimate < 0.005
        if near_nw and current_price < nw_estimate and self.ema_fast[0] < self.ema_slow[0]:
            self.log('SELL: Rejection from NW line resistance')
            return True
        
        # Signal 4: Extreme overbought above upper envelope
        if current_price > upper_env * 1.005 and self.rsi[0] > 70:
            self.log('SELL: Extreme overbought above envelope')
            return True
        
        # Signal 5: Envelope expansion with price reversal
        envelope_width = upper_env - lower_env
        if len(self.upper_envelope) > 2:
            prev_width = self.upper_envelope[-2] - self.lower_envelope[-2]
            if envelope_width > prev_width * 1.2 and current_price < self.dataclose[-1]:
                self.log('SELL: Envelope expansion with reversal')
                return True
        
        return False
