"""
SuperTrend Strategy
ATR-based dynamic trend following system
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class SuperTrendStrategy(BaseStrategy):
    """SuperTrend - Dynamic trend following with ATR bands"""
    
    strategy_name = "SuperTrend Pro"
    
    params = (
        # SuperTrend settings
        ('period', 10),
        ('multiplier', 3.0),
        
        # Multi-timeframe
        ('use_multi_timeframe', True),
        ('tf2_period', 20),
        ('tf2_multiplier', 5.0),
        
        # Filters
        ('use_volume_filter', True),
        ('use_adx_filter', True),
        ('adx_threshold', 25),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 3.0),
        ('leverage', 15),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # ATR
        self.atr = bt.indicators.ATR(self.datas[0], period=self.params.period)
        
        # Basic bands
        hl_avg = (self.datahigh + self.datalow) / 2
        
        # SuperTrend bands
        self.up_band = hl_avg - (self.params.multiplier * self.atr)
        self.down_band = hl_avg + (self.params.multiplier * self.atr)
        
        # Initialize SuperTrend line
        self.supertrend = [0]
        self.trend = [1]  # 1 for uptrend, -1 for downtrend
        
        # Second timeframe SuperTrend
        if self.params.use_multi_timeframe:
            self.atr2 = bt.indicators.ATR(self.datas[0], period=self.params.tf2_period)
            self.up_band2 = hl_avg - (self.params.tf2_multiplier * self.atr2)
            self.down_band2 = hl_avg + (self.params.tf2_multiplier * self.atr2)
            self.supertrend2 = [0]
            self.trend2 = [1]
        
        # ADX for trend strength
        if self.params.use_adx_filter:
            self.adx = bt.indicators.ADX(self.datas[0], period=14)
        
        # Volume
        self.volume_sma = bt.indicators.SMA(self.datas[0].volume, period=20)
        
        # Additional indicators
        self.rsi = bt.indicators.RSI(self.dataclose, period=14)
        self.ema_fast = bt.indicators.EMA(self.dataclose, period=20)
        self.ema_slow = bt.indicators.EMA(self.dataclose, period=50)
        
        # MACD for confirmation
        self.macd = bt.indicators.MACD(self.dataclose)
        
        # Track trend changes
        self.trend_changes = 0
        self.bars_in_trend = 0
        
    def calculate_supertrend(self):
        """Calculate SuperTrend values"""
        
        if len(self) < 2:
            return
        
        # Previous values
        prev_trend = self.trend[-1]
        prev_supertrend = self.supertrend[-1]
        
        # Current bands
        up = self.up_band[0]
        down = self.down_band[0]
        
        # Adjust bands based on previous values
        if up > prev_supertrend or self.dataclose[-1] < prev_supertrend:
            final_up = up
        else:
            final_up = prev_supertrend
        
        if down < prev_supertrend or self.dataclose[-1] > prev_supertrend:
            final_down = down
        else:
            final_down = prev_supertrend
        
        # Determine current trend
        if prev_trend == 1:
            if self.dataclose[0] <= final_up:
                current_trend = -1
                current_supertrend = final_down
                self.trend_changes += 1
                self.bars_in_trend = 0
            else:
                current_trend = 1
                current_supertrend = final_up
                self.bars_in_trend += 1
        else:
            if self.dataclose[0] >= final_down:
                current_trend = 1
                current_supertrend = final_up
                self.trend_changes += 1
                self.bars_in_trend = 0
            else:
                current_trend = -1
                current_supertrend = final_down
                self.bars_in_trend += 1
        
        # Store values
        self.trend.append(current_trend)
        self.supertrend.append(current_supertrend)
        
        # Calculate second timeframe if enabled
        if self.params.use_multi_timeframe:
            self.calculate_supertrend2()
    
    def calculate_supertrend2(self):
        """Calculate second timeframe SuperTrend"""
        
        if len(self) < 2:
            return
        
        prev_trend2 = self.trend2[-1]
        prev_supertrend2 = self.supertrend2[-1]
        
        up2 = self.up_band2[0]
        down2 = self.down_band2[0]
        
        if up2 > prev_supertrend2 or self.dataclose[-1] < prev_supertrend2:
            final_up2 = up2
        else:
            final_up2 = prev_supertrend2
        
        if down2 < prev_supertrend2 or self.dataclose[-1] > prev_supertrend2:
            final_down2 = down2
        else:
            final_down2 = prev_supertrend2
        
        if prev_trend2 == 1:
            if self.dataclose[0] <= final_up2:
                current_trend2 = -1
                current_supertrend2 = final_down2
            else:
                current_trend2 = 1
                current_supertrend2 = final_up2
        else:
            if self.dataclose[0] >= final_down2:
                current_trend2 = 1
                current_supertrend2 = final_up2
            else:
                current_trend2 = -1
                current_supertrend2 = final_down2
        
        self.trend2.append(current_trend2)
        self.supertrend2.append(current_supertrend2)
    
    def buy_signal(self):
        """Generate buy signals based on SuperTrend"""
        
        # Calculate current SuperTrend
        self.calculate_supertrend()
        
        if len(self.trend) < 2:
            return False
        
        # Signal 1: Trend change from bearish to bullish
        trend_flip = self.trend[-1] == 1 and self.trend[-2] == -1
        
        if trend_flip:
            # Check filters
            filters_pass = True
            
            # ADX filter
            if self.params.use_adx_filter and self.adx[0] < self.params.adx_threshold:
                filters_pass = False
            
            # Volume filter
            if self.params.use_volume_filter and self.volume[0] < self.volume_sma[0]:
                filters_pass = False
            
            if filters_pass:
                self.log('BUY: SuperTrend flip to bullish')
                return True
        
        # Signal 2: Multi-timeframe alignment
        if self.params.use_multi_timeframe and len(self.trend2) >= 2:
            both_bullish = self.trend[-1] == 1 and self.trend2[-1] == 1
            tf1_just_flipped = self.trend[-1] == 1 and self.trend[-2] == -1
            
            if both_bullish and tf1_just_flipped:
                self.log('BUY: Multi-timeframe SuperTrend alignment')
                return True
        
        # Signal 3: Pullback to SuperTrend in uptrend
        if len(self.supertrend) > 0:
            in_uptrend = self.trend[-1] == 1 and self.bars_in_trend > 5
            near_supertrend = abs(self.dataclose[0] - self.supertrend[-1]) / self.supertrend[-1] < 0.005
            
            if in_uptrend and near_supertrend and self.rsi[0] < 50:
                self.log('BUY: Pullback to SuperTrend support')
                return True
        
        # Signal 4: Strong trend continuation
        strong_uptrend = (
            self.trend[-1] == 1 and
            self.ema_fast[0] > self.ema_slow[0] and
            self.macd.macd[0] > self.macd.signal[0] and
            self.adx[0] > 30
        )
        
        if strong_uptrend and self.dataclose[0] > self.supertrend[-1] * 1.01:
            self.log('BUY: Strong trend continuation')
            return True
        
        return False
    
    def sell_signal(self):
        """Generate sell signals based on SuperTrend"""
        
        if not self.position or len(self.trend) < 2:
            return False
        
        # Signal 1: Trend change from bullish to bearish
        trend_flip = self.trend[-1] == -1 and self.trend[-2] == 1
        
        if trend_flip:
            self.log('SELL: SuperTrend flip to bearish')
            return True
        
        # Signal 2: Multi-timeframe misalignment
        if self.params.use_multi_timeframe and len(self.trend2) >= 2:
            tf2_bearish = self.trend2[-1] == -1
            
            if tf2_bearish and self.trend[-1] == -1:
                self.log('SELL: Multi-timeframe SuperTrend bearish')
                return True
        
        # Signal 3: Price far from SuperTrend (take profit)
        if len(self.supertrend) > 0 and self.trend[-1] == 1:
            distance = (self.dataclose[0] - self.supertrend[-1]) / self.supertrend[-1]
            
            if distance > 0.05:  # 5% above SuperTrend
                self.log('SELL: Extended from SuperTrend')
                return True
        
        # Signal 4: Weak trend with RSI overbought
        weak_trend = self.adx[0] < 20 and self.rsi[0] > 70
        
        if weak_trend:
            self.log('SELL: Weak trend with RSI overbought')
            return True
        
        # Signal 5: MACD divergence
        if self.macd.macd[0] < self.macd.signal[0] and self.trend[-1] == -1:
            self.log('SELL: MACD bearish with SuperTrend')
            return True
        
        return False
