"""
Base Strategy Template
Copy this file to create new strategies
"""

import backtrader as bt
import sys
import os

# Add parent directory to path to allow imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class BaseStrategy(bt.Strategy):
    """Base strategy with risk management and leverage support"""
    
    params = (
        ('printlog', False),
        ('risk_per_trade', 2.0),  # Risk 2% of account per trade
        ('leverage', 1),  # Leverage multiplier (1-125x)
        ('stop_loss_pct', 2.0),  # Stop loss percentage
        ('take_profit_pct', 6.0),  # Take profit percentage
        ('use_risk_management', True),  # Enable/disable risk management
    )
    
    def __init__(self):
        self.order = None
        self.stop_order = None
        self.profit_order = None
        self.trades_list = []
        self.trade_count = 0
        self.win_count = 0
        self.dataclose = self.datas[0].close
        self.datahigh = self.datas[0].high
        self.datalow = self.datas[0].low
        self.dataopen = self.datas[0].open
        
        # Track entry price
        self.entry_price = None
        self.position_size = None
        
    def log(self, txt, dt=None):
        """Logging function"""
        if self.params.printlog:
            dt = dt or self.datas[0].datetime.date(0)
            print(f'{dt.isoformat()} {txt}')
    
    def calculate_position_size(self):
        """Calculate position size based on risk management"""
        account_value = self.broker.getvalue()
        
        if self.params.use_risk_management:
            # Calculate position size based on risk percentage
            risk_amount = account_value * (self.params.risk_per_trade / 100)
            
            # With leverage
            effective_capital = risk_amount * self.params.leverage
            
            # Position size in units
            position_size = effective_capital / self.dataclose[0]
        else:
            # Use all available capital with leverage
            available_cash = self.broker.getcash()
            effective_capital = available_cash * self.params.leverage * 0.95  # Use 95% to avoid margin issues
            position_size = effective_capital / self.dataclose[0]
        
        return position_size
    
    def buy_signal(self):
        """Override this method in child strategies"""
        return False
    
    def sell_signal(self):
        """Override this method in child strategies"""
        return False
    
    def next(self):
        # Skip if we have pending orders
        if self.order:
            return
        
        # Check if we are in the market
        if not self.position:
            # Check for buy signal
            if self.buy_signal():
                # Calculate position size with risk management
                size = self.calculate_position_size()
                
                if size > 0:
                    self.log(f'BUY CREATE, Size: {size:.4f} @ {self.dataclose[0]:.2f} (Leverage: {self.params.leverage}x)')
                    self.order = self.buy(size=size)
                    self.entry_price = self.dataclose[0]
                    self.position_size = size
        else:
            # Check for sell signal or stop/take profit
            current_pnl_pct = ((self.dataclose[0] - self.entry_price) / self.entry_price) * 100
            
            # Check stop loss
            if self.params.use_risk_management and current_pnl_pct <= -self.params.stop_loss_pct:
                self.log(f'STOP LOSS TRIGGERED @ {self.dataclose[0]:.2f} (Loss: {current_pnl_pct:.2f}%)')
                self.order = self.close()
            
            # Check take profit
            elif self.params.use_risk_management and current_pnl_pct >= self.params.take_profit_pct:
                self.log(f'TAKE PROFIT TRIGGERED @ {self.dataclose[0]:.2f} (Profit: {current_pnl_pct:.2f}%)')
                self.order = self.close()
            
            # Check strategy sell signal
            elif self.sell_signal():
                self.log(f'SELL SIGNAL @ {self.dataclose[0]:.2f} (P/L: {current_pnl_pct:.2f}%)')
                self.order = self.close()
    
    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(f'BUY EXECUTED, Price: {order.executed.price:.2f}, Size: {order.executed.size:.4f}')
            else:
                self.log(f'SELL EXECUTED, Price: {order.executed.price:.2f}')
            
            self.bar_executed = len(self)
            
        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log('Order Canceled/Margin/Rejected')
        
        self.order = None
    
    def notify_trade(self, trade):
        if not trade.isclosed:
            return
        
        self.trade_count += 1
        if trade.pnl > 0:
            self.win_count += 1
        
        self.log(f'TRADE CLOSED, GROSS P/L: {trade.pnl:.2f}, NET P/L: {trade.pnlcomm:.2f}')
        
        self.trades_list.append({
            'profit': trade.pnl,
            'pnlcomm': trade.pnlcomm,
        })
        
        # Reset entry price
        self.entry_price = None
        self.position_size = None
