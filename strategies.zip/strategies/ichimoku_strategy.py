"""
Ichimoku Cloud Strategy
Advanced Japanese trading system
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy

class IchimokuStrategy(BaseStrategy):
    """Ichimoku Cloud strategy for trend following"""
    
    strategy_name = "Ichimoku Cloud"
    
    params = (
        ('tenkan', 9),  # Conversion line
        ('kijun', 26),  # Base line
        ('senkou', 52),  # Leading span B
        ('chikou', 26),  # Lagging span
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 3),
        ('stop_loss_pct', 3.0),
        ('take_profit_pct', 9.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Tenkan-sen (Conversion Line) = (9-period high + 9-period low)/2
        self.high9 = bt.indicators.Highest(self.datahigh, period=self.params.tenkan)
        self.low9 = bt.indicators.Lowest(self.datalow, period=self.params.tenkan)
        self.tenkan_sen = (self.high9 + self.low9) / 2
        
        # Kijun-sen (Base Line) = (26-period high + 26-period low)/2
        self.high26 = bt.indicators.Highest(self.datahigh, period=self.params.kijun)
        self.low26 = bt.indicators.Lowest(self.datalow, period=self.params.kijun)
        self.kijun_sen = (self.high26 + self.low26) / 2
        
        # Senkou Span A (Leading Span A) = (Tenkan-sen + Kijun-sen)/2
        self.senkou_span_a = (self.tenkan_sen + self.kijun_sen) / 2
        
        # Senkou Span B (Leading Span B) = (52-period high + 52-period low)/2
        self.high52 = bt.indicators.Highest(self.datahigh, period=self.params.senkou)
        self.low52 = bt.indicators.Lowest(self.datalow, period=self.params.senkou)
        self.senkou_span_b = (self.high52 + self.low52) / 2
        
        # Track crossovers
        self.tenkan_kijun_cross = bt.indicators.CrossOver(self.tenkan_sen, self.kijun_sen)
        
    def buy_signal(self):
        """Buy when:
        1. Price is above the cloud
        2. Tenkan crosses above Kijun
        3. Cloud is green (Span A > Span B)
        """
        price_above_cloud = (self.dataclose[0] > self.senkou_span_a[0] and 
                            self.dataclose[0] > self.senkou_span_b[0])
        
        cloud_is_green = self.senkou_span_a[0] > self.senkou_span_b[0]
        
        return (self.tenkan_kijun_cross > 0 and 
                price_above_cloud and 
                cloud_is_green)
    
    def sell_signal(self):
        """Sell when:
        1. Tenkan crosses below Kijun
        2. Price enters the cloud
        """
        price_in_cloud = (self.dataclose[0] < max(self.senkou_span_a[0], self.senkou_span_b[0]) and
                         self.dataclose[0] > min(self.senkou_span_a[0], self.senkou_span_b[0]))
        
        return self.tenkan_kijun_cross < 0 or price_in_cloud
