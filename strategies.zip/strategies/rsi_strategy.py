"""
RSI Strategy with Dynamic Levels
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy

class RSIStrategy(BaseStrategy):
    """RSI Strategy with dynamic overbought/oversold levels"""
    
    strategy_name = "RSI Dynamic"
    
    params = (
        ('rsi_period', 14),
        ('rsi_oversold', 35),
        ('rsi_overbought', 65),
        ('rsi_exit_oversold', 45),  # Exit long when RSI rises above this
        ('rsi_exit_overbought', 55),  # Exit short when RSI falls below this
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 1),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # RSI indicator
        self.rsi = bt.indicators.RSI(self.dataclose, period=self.params.rsi_period)
        
        # Track RSI trend
        self.rsi_sma = bt.indicators.SMA(self.rsi, period=5)
        
    def buy_signal(self):
        """Buy when RSI is oversold and starting to turn up"""
        return (self.rsi[0] < self.params.rsi_oversold and 
                self.rsi[0] > self.rsi[-1])  # RSI turning up
    
    def sell_signal(self):
        """Sell when RSI is overbought or exits oversold zone"""
        if self.position.size > 0:  # Long position
            return (self.rsi[0] > self.params.rsi_overbought or
                    (self.rsi[0] > self.params.rsi_exit_oversold and self.rsi[0] < self.rsi[-1]))
        return False
