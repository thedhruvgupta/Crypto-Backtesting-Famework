"""
Grid Trading Strategy
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy

class GridStrategy(BaseStrategy):
    """Grid trading strategy for ranging markets"""
    
    strategy_name = "Grid Trading"
    
    params = (
        ('grid_levels', 5),  # Number of grid levels
        ('grid_spacing', 1.0),  # Percentage spacing between levels
        ('base_size', 0.2),  # Base position size per grid level
        ('use_dynamic_grid', True),  # Adjust grid based on ATR
        ('atr_period', 14),
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 5),
        ('stop_loss_pct', 3.0),
        ('take_profit_pct', 3.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # ATR for dynamic grid spacing
        self.atr = bt.indicators.ATR(self.datas[0], period=self.params.atr_period)
        
        # Bollinger Bands to identify range
        self.bbands = bt.indicators.BollingerBands(self.dataclose, period=20, devfactor=2)
        
        # Track grid levels
        self.grid_levels = []
        self.last_grid_update = 0
        self.grid_orders = {}
        
    def update_grid_levels(self):
        """Update grid levels based on current price and volatility"""
        current_price = self.dataclose[0]
        
        if self.params.use_dynamic_grid:
            # Use ATR for dynamic spacing
            spacing = (self.atr[0] / current_price) * 100
        else:
            spacing = self.params.grid_spacing
        
        # Calculate grid levels
        self.grid_levels = []
        for i in range(-self.params.grid_levels, self.params.grid_levels + 1):
            if i != 0:  # Skip current price level
                level = current_price * (1 + (i * spacing / 100))
                self.grid_levels.append(level)
        
        self.last_grid_update = len(self)
        
    def buy_signal(self):
        """Buy at lower grid levels"""
        # Update grid if needed (every 20 bars)
        if len(self) - self.last_grid_update > 20 or not self.grid_levels:
            self.update_grid_levels()
        
        current_price = self.dataclose[0]
        
        # Check if price is at a buy grid level
        for level in self.grid_levels:
            if level < current_price and abs(current_price - level) / level < 0.002:  # Within 0.2% of level
                return True
        
        # Also buy on bounce from lower Bollinger Band
        return self.dataclose[0] <= self.bbands.bot[0] * 1.001
    
    def sell_signal(self):
        """Sell at upper grid levels or take profit"""
        if not self.position:
            return False
        
        current_price = self.dataclose[0]
        
        # Check if price is at a sell grid level
        for level in self.grid_levels:
            if level > self.entry_price and abs(current_price - level) / level < 0.002:
                return True
        
        # Also sell at upper Bollinger Band
        return self.dataclose[0] >= self.bbands.top[0] * 0.999
