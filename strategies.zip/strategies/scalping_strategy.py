"""
Scalping Strategy for Quick Trades
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy

class ScalpingStrategy(BaseStrategy):
    """High-frequency scalping strategy for 1m-5m timeframes"""
    
    strategy_name = "Scalper Pro"
    
    params = (
        ('ema_fast', 5),
        ('ema_slow', 13),
        ('rsi_period', 7),
        ('rsi_oversold', 30),
        ('rsi_overbought', 70),
        ('atr_period', 14),
        ('atr_multiplier', 1.5),
        ('printlog', False),
        ('risk_per_trade', 1.0),  # Lower risk for scalping
        ('leverage', 10),  # Higher leverage for scalping
        ('stop_loss_pct', 0.5),  # Tight stop loss
        ('take_profit_pct', 1.0),  # Quick profit taking
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # EMAs for trend
        self.ema_fast = bt.indicators.EMA(self.dataclose, period=self.params.ema_fast)
        self.ema_slow = bt.indicators.EMA(self.dataclose, period=self.params.ema_slow)
        
        # RSI for momentum
        self.rsi = bt.indicators.RSI(self.dataclose, period=self.params.rsi_period)
        
        # ATR for volatility
        self.atr = bt.indicators.ATR(self.datas[0], period=self.params.atr_period)
        
        # VWAP approximation (using volume-weighted average)
        self.vwap = bt.indicators.WeightedAverage(self.dataclose, self.volume, period=20)
        
        # Momentum
        self.momentum = bt.indicators.Momentum(self.dataclose, period=10)
        
    def buy_signal(self):
        """Scalping buy signal with multiple confirmations"""
        return (self.ema_fast[0] > self.ema_slow[0] and  # Uptrend
                self.dataclose[0] > self.ema_fast[0] and  # Price above fast EMA
                self.rsi[0] > 50 and self.rsi[0] < self.params.rsi_overbought and  # Momentum up but not overbought
                self.momentum[0] > 100 and  # Positive momentum
                self.atr[0] > self.atr[-1])  # Increasing volatility
    
    def sell_signal(self):
        """Quick exit for scalping"""
        if self.position.size > 0:
            # Exit conditions for long position
            return (self.ema_fast[0] < self.ema_slow[0] or  # Trend reversal
                    self.rsi[0] > self.params.rsi_overbought or  # Overbought
                    self.momentum[0] < 100)  # Momentum loss
        return False
