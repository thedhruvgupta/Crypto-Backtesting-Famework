"""
Market Cipher B Strategy
Based on the popular TradingView indicator with WaveTrend, RSI, and MFI
"""

import backtrader as bt
import sys
import os
import numpy as np

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class MarketCipherBStrategy(BaseStrategy):
    """Market Cipher B - Advanced momentum oscillator strategy"""
    
    strategy_name = "Market Cipher B"
    
    params = (
        # WaveTrend settings
        ('wt_channel_len', 9),
        ('wt_average_len', 12),
        ('wt_ma_len', 3),
        ('wt_oversold_1', -53),
        ('wt_oversold_2', -60),
        ('wt_overbought_1', 53),
        ('wt_overbought_2', 60),
        
        # RSI settings
        ('rsi_period', 14),
        ('rsi_oversold', 30),
        ('rsi_overbought', 70),
        
        # MFI settings
        ('mfi_period', 60),
        ('mfi_multiplier', 150),
        ('mfi_area_multiplier', 2.5),
        
        # Stochastic RSI settings
        ('stoch_period', 14),
        ('stoch_rsi_period', 14),
        ('stoch_k_smooth', 3),
        ('stoch_d_smooth', 3),
        
        # Strategy thresholds
        ('buy_threshold', -40),  # WT level for buy
        ('sell_threshold', 40),   # WT level for sell
        ('divergence_lookback', 50),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 3.0),
        ('leverage', 10),
        ('stop_loss_pct', 3.0),
        ('take_profit_pct', 9.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Calculate HLC3 (typical price)
        self.hlc3 = (self.datahigh + self.datalow + self.dataclose) / 3
        
        # WaveTrend Calculation
        self.esa = bt.indicators.EMA(self.hlc3, period=self.params.wt_channel_len)
        
        # Calculate absolute difference for WaveTrend
        self.de = bt.indicators.EMA(abs(self.hlc3 - self.esa), period=self.params.wt_channel_len)
        
        # CI (Channel Index)
        self.ci = (self.hlc3 - self.esa) / (0.015 * self.de)
        
        # WaveTrend lines
        self.wt1 = bt.indicators.EMA(self.ci, period=self.params.wt_average_len)
        self.wt2 = bt.indicators.SMA(self.wt1, period=self.params.wt_ma_len)
        
        # WaveTrend Cross
        self.wt_cross = bt.indicators.CrossOver(self.wt1, self.wt2)
        
        # RSI
        self.rsi = bt.indicators.RSI(self.dataclose, period=self.params.rsi_period)
        
        # Money Flow Index (simplified version)
        self.mfi = bt.indicators.MoneyFlowIndicator(
            self.datas[0],
            period=self.params.mfi_period
        )
        
        # Stochastic RSI
        self.stoch_rsi = bt.indicators.StochasticFull(
            self.datas[0],
            period=self.params.stoch_period,
            period_dfast=self.params.stoch_k_smooth,
            period_dslow=self.params.stoch_d_smooth
        )
        
        # Track divergences
        self.wt1_peaks = []
        self.price_peaks = []
        self.wt1_troughs = []
        self.price_troughs = []
        
        # Volume analysis
        self.volume_sma = bt.indicators.SMA(self.datas[0].volume, period=20)
        
        # Track signals
        self.buy_signal_fired = False
        self.sell_signal_fired = False
        
    def detect_divergence(self):
        """Detect bullish and bearish divergences"""
        
        # Store recent peaks and troughs (simplified)
        if len(self.wt1) > 5:
            # Detect peaks (local maxima)
            if self.wt1[-2] > self.wt1[-3] and self.wt1[-2] > self.wt1[-1]:
                self.wt1_peaks.append((len(self), self.wt1[-2]))
                self.price_peaks.append((len(self), self.dataclose[-2]))
                
                # Keep only recent peaks
                if len(self.wt1_peaks) > 10:
                    self.wt1_peaks.pop(0)
                    self.price_peaks.pop(0)
            
            # Detect troughs (local minima)
            if self.wt1[-2] < self.wt1[-3] and self.wt1[-2] < self.wt1[-1]:
                self.wt1_troughs.append((len(self), self.wt1[-2]))
                self.price_troughs.append((len(self), self.dataclose[-2]))
                
                # Keep only recent troughs
                if len(self.wt1_troughs) > 10:
                    self.wt1_troughs.pop(0)
                    self.price_troughs.pop(0)
        
        # Check for bullish divergence (price lower low, indicator higher low)
        bullish_div = False
        if len(self.wt1_troughs) >= 2:
            recent_trough = self.wt1_troughs[-1]
            prev_trough = self.wt1_troughs[-2]
            recent_price = self.price_troughs[-1]
            prev_price = self.price_troughs[-2]
            
            if (recent_price[1] < prev_price[1] and  # Price made lower low
                recent_trough[1] > prev_trough[1] and  # WT made higher low
                self.wt1[0] < self.params.wt_oversold_1):  # Currently oversold
                bullish_div = True
        
        # Check for bearish divergence (price higher high, indicator lower high)
        bearish_div = False
        if len(self.wt1_peaks) >= 2:
            recent_peak = self.wt1_peaks[-1]
            prev_peak = self.wt1_peaks[-2]
            recent_price = self.price_peaks[-1]
            prev_price = self.price_peaks[-2]
            
            if (recent_price[1] > prev_price[1] and  # Price made higher high
                recent_peak[1] < prev_peak[1] and  # WT made lower high
                self.wt1[0] > self.params.wt_overbought_1):  # Currently overbought
                bearish_div = True
        
        return bullish_div, bearish_div
    
    def get_market_cipher_signals(self):
        """Generate Market Cipher B buy/sell signals"""
        
        # Detect divergences
        bullish_div, bearish_div = self.detect_divergence()
        
        # Buy Signal (Green Circle)
        buy_signal = (
            self.wt1[0] < self.params.wt_oversold_2 and
            self.wt_cross > 0 and  # WT cross up
            self.rsi[0] < 35 and  # RSI oversold
            self.mfi[0] < 30  # MFI oversold
        )
        
        # Strong Buy Signal (Gold Circle)
        gold_buy_signal = (
            bullish_div and
            self.wt1[0] < self.params.wt_oversold_2 and
            self.wt2[0] > self.params.wt_oversold_2 and
            self.rsi[0] < 30
        )
        
        # Sell Signal (Red Circle)
        sell_signal = (
            self.wt1[0] > self.params.wt_overbought_2 and
            self.wt_cross < 0 and  # WT cross down
            self.rsi[0] > 65 and  # RSI overbought
            self.mfi[0] > 70  # MFI overbought
        )
        
        # Strong Sell Signal (With Divergence)
        div_sell_signal = (
            bearish_div and
            self.wt1[0] > self.params.wt_overbought_1 and
            self.rsi[0] > 70
        )
        
        return buy_signal, gold_buy_signal, sell_signal, div_sell_signal
    
    def buy_signal(self):
        """Generate buy signal based on Market Cipher B logic"""
        
        buy_signal, gold_buy_signal, _, _ = self.get_market_cipher_signals()
        
        # Basic conditions
        basic_buy = (
            self.wt1[0] < self.params.buy_threshold and
            self.wt2[0] < self.params.buy_threshold and
            self.wt_cross > 0  # Crossing up
        )
        
        # RSI confirmation
        rsi_confirm = self.rsi[0] < self.params.rsi_oversold + 10
        
        # MFI confirmation
        mfi_confirm = self.mfi[0] < 40
        
        # Volume confirmation
        volume_confirm = self.datas[0].volume[0] > self.volume_sma[0]
        
        # Stochastic confirmation
        stoch_confirm = self.stoch_rsi.percK[0] < 20 or self.stoch_rsi.percD[0] < 20
        
        # Fire buy signal if we have strong confluence
        if gold_buy_signal:
            self.log('GOLD BUY SIGNAL - Strong bullish divergence detected')
            return True
        elif buy_signal:
            self.log('BUY SIGNAL - Market Cipher B buy conditions met')
            return True
        elif basic_buy and (rsi_confirm or mfi_confirm) and volume_confirm:
            self.log('BUY SIGNAL - Basic conditions with confirmation')
            return True
        elif basic_buy and stoch_confirm:
            self.log('BUY SIGNAL - WaveTrend with Stochastic confirmation')
            return True
            
        return False
    
    def sell_signal(self):
        """Generate sell signal based on Market Cipher B logic"""
        
        _, _, sell_signal, div_sell_signal = self.get_market_cipher_signals()
        
        # Basic conditions
        basic_sell = (
            self.wt1[0] > self.params.sell_threshold and
            self.wt2[0] > self.params.sell_threshold and
            self.wt_cross < 0  # Crossing down
        )
        
        # RSI confirmation
        rsi_confirm = self.rsi[0] > self.params.rsi_overbought - 10
        
        # MFI confirmation
        mfi_confirm = self.mfi[0] > 60
        
        # Stochastic confirmation
        stoch_confirm = self.stoch_rsi.percK[0] > 80 or self.stoch_rsi.percD[0] > 80
        
        # Fire sell signal if we have strong confluence
        if div_sell_signal:
            self.log('DIVERGENCE SELL SIGNAL - Bearish divergence detected')
            return True
        elif sell_signal:
            self.log('SELL SIGNAL - Market Cipher B sell conditions met')
            return True
        elif basic_sell and (rsi_confirm or mfi_confirm):
            self.log('SELL SIGNAL - Basic conditions with confirmation')
            return True
        elif basic_sell and stoch_confirm:
            self.log('SELL SIGNAL - WaveTrend with Stochastic confirmation')
            return True
        
        # Also exit if WT crosses mid-line from above
        if self.position.size > 0:
            if self.wt1[0] < 0 and self.wt1[-1] > 0:
                self.log('SELL SIGNAL - WaveTrend crossed below zero')
                return True
                
        return False


class MoneyFlowIndicator(bt.Indicator):
    """Custom Money Flow Index indicator for Market Cipher B"""
    
    lines = ('mfi',)
    params = (('period', 14),)
    
    def __init__(self):
        # Typical Price
        tp = (self.data.high + self.data.low + self.data.close) / 3
        
        # Raw Money Flow
        mf = tp * self.data.volume
        
        # Positive and Negative Money Flow
        up = bt.If(tp > tp(-1), mf, 0)
        down = bt.If(tp < tp(-1), mf, 0)
        
        # Money Flow Ratio
        pos_mf = bt.indicators.SumN(up, period=self.p.period)
        neg_mf = bt.indicators.SumN(down, period=self.p.period)
        
        # Avoid division by zero
        mfr = pos_mf / bt.If(neg_mf > 0, neg_mf, 0.001)
        
        # Money Flow Index
        self.lines.mfi = 100 - (100 / (1 + mfr))


# Register the custom indicator
bt.indicators.MoneyFlowIndicator = MoneyFlowIndicator
