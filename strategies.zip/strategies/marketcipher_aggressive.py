"""
Market Cipher B Aggressive Strategy
More responsive version with frequent trading signals
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class MarketCipherAggressiveStrategy(BaseStrategy):
    """Market Cipher B Aggressive - High frequency momentum strategy"""
    
    strategy_name = "MC-B Aggressive"
    
    params = (
        # WaveTrend settings (more responsive)
        ('wt_channel_len', 7),  # Faster than default 9
        ('wt_average_len', 10),  # Faster than default 12
        ('wt_ma_len', 3),
        ('wt_oversold', -40),  # Less strict than -53
        ('wt_overbought', 40),  # Less strict than 53
        
        # RSI settings (more responsive)
        ('rsi_period', 9),  # Faster than 14
        ('rsi_oversold', 35),
        ('rsi_overbought', 65),
        
        # Trade management
        ('use_wt_cross', True),  # Trade on every WT cross
        ('use_momentum', True),  # Use momentum confirmation
        ('min_profit_exit', 0.5),  # Exit with small profit
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 3.0),
        ('leverage', 20),  # Higher leverage for scalping
        ('stop_loss_pct', 1.5),  # Tighter stop
        ('take_profit_pct', 4.5),  # Smaller target
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # HLC3 (typical price)
        self.hlc3 = (self.datahigh + self.datalow + self.dataclose) / 3
        
        # WaveTrend Oscillator
        self.esa = bt.indicators.EMA(self.hlc3, period=self.params.wt_channel_len)
        self.de = bt.indicators.EMA(abs(self.hlc3 - self.esa), period=self.params.wt_channel_len)
        
        # Avoid division by zero
        self.ci = (self.hlc3 - self.esa) / bt.If(self.de > 0, 0.015 * self.de, 0.0001)
        
        # WaveTrend lines
        self.wt1 = bt.indicators.EMA(self.ci, period=self.params.wt_average_len)
        self.wt2 = bt.indicators.SMA(self.wt1, period=self.params.wt_ma_len)
        
        # WT Cross
        self.wt_cross = bt.indicators.CrossOver(self.wt1, self.wt2)
        
        # RSI
        self.rsi = bt.indicators.RSI(self.dataclose, period=self.params.rsi_period)
        
        # Fast RSI for momentum
        self.fast_rsi = bt.indicators.RSI(self.dataclose, period=5)
        
        # Momentum
        self.momentum = bt.indicators.Momentum(self.dataclose, period=10)
        
        # MACD for trend
        self.macd = bt.indicators.MACD(self.dataclose)
        
        # Volume
        self.volume_sma = bt.indicators.SMA(self.datas[0].volume, period=10)
        
        # ATR for volatility
        self.atr = bt.indicators.ATR(self.datas[0], period=14)
        
        # Track recent action
        self.bars_since_entry = 0
        self.entry_wt = None
        
    def buy_signal(self):
        """Aggressive buy signals"""
        
        # Update bars since entry
        if not self.position:
            self.bars_since_entry = 0
        
        # Signal 1: WT Oversold Cross Up
        wt_buy = (
            self.wt1[0] < self.params.wt_oversold and
            self.wt_cross > 0
        )
        
        # Signal 2: WT Cross Up with RSI confirmation
        wt_cross_buy = (
            self.params.use_wt_cross and
            self.wt_cross > 0 and
            self.wt1[0] < 0 and  # Below zero line
            self.rsi[0] < 50  # RSI not overbought
        )
        
        # Signal 3: Momentum reversal
        momentum_buy = (
            self.params.use_momentum and
            self.wt1[0] < -20 and
            self.wt1[0] > self.wt1[-1] and  # WT turning up
            self.momentum[0] > 99.5 and  # Momentum positive
            self.fast_rsi[0] > self.fast_rsi[-1]  # Fast RSI rising
        )
        
        # Signal 4: Strong oversold bounce
        oversold_bounce = (
            self.wt1[0] < -50 and
            self.rsi[0] < 30 and
            self.dataclose[0] > self.dataclose[-1]  # Price rising
        )
        
        # Signal 5: MACD support
        macd_buy = (
            self.wt1[0] < 0 and
            self.macd.macd[0] > self.macd.signal[0] and
            self.macd.macd[0] > self.macd.macd[-1]  # MACD rising
        )
        
        # Signal 6: Volume spike buy
        volume_buy = (
            self.wt1[0] < -10 and
            self.datas[0].volume[0] > self.volume_sma[0] * 1.5 and
            self.dataclose[0] > self.dataopen[0]  # Green candle
        )
        
        # Fire buy signal
        if wt_buy:
            self.log('BUY: WT Oversold Cross Up')
            self.entry_wt = self.wt1[0]
            return True
        elif wt_cross_buy:
            self.log('BUY: WT Cross Up Below Zero')
            self.entry_wt = self.wt1[0]
            return True
        elif momentum_buy:
            self.log('BUY: Momentum Reversal')
            self.entry_wt = self.wt1[0]
            return True
        elif oversold_bounce:
            self.log('BUY: Strong Oversold Bounce')
            self.entry_wt = self.wt1[0]
            return True
        elif macd_buy:
            self.log('BUY: MACD Support')
            self.entry_wt = self.wt1[0]
            return True
        elif volume_buy:
            self.log('BUY: Volume Spike')
            self.entry_wt = self.wt1[0]
            return True
            
        return False
    
    def sell_signal(self):
        """Aggressive sell signals"""
        
        if not self.position:
            return False
        
        # Update bars since entry
        self.bars_since_entry += 1
        
        # Calculate current P/L if in position
        if self.entry_price:
            current_pnl = ((self.dataclose[0] - self.entry_price) / self.entry_price) * 100
        else:
            current_pnl = 0
        
        # Signal 1: WT Overbought Cross Down
        wt_sell = (
            self.wt1[0] > self.params.wt_overbought and
            self.wt_cross < 0
        )
        
        # Signal 2: WT Cross Down
        wt_cross_sell = (
            self.params.use_wt_cross and
            self.wt_cross < 0 and
            self.wt1[0] > 0  # Above zero line
        )
        
        # Signal 3: Momentum loss
        momentum_sell = (
            self.params.use_momentum and
            self.wt1[0] > 20 and
            self.wt1[0] < self.wt1[-1] and  # WT turning down
            self.momentum[0] < 100.5
        )
        
        # Signal 4: Take small profit
        quick_profit = (
            current_pnl > self.params.min_profit_exit and
            self.wt1[0] > 10 and
            self.wt1[0] < self.wt1[-1]  # WT turning down
        )
        
        # Signal 5: RSI overbought
        rsi_sell = (
            self.rsi[0] > self.params.rsi_overbought and
            self.wt1[0] > 30
        )
        
        # Signal 6: Time-based exit
        time_exit = (
            self.bars_since_entry > 50 and  # Been in trade for a while
            current_pnl > 0 and  # In profit
            self.wt1[0] < self.wt1[-1]  # WT turning down
        )
        
        # Signal 7: WT reversal from entry
        wt_reversal = (
            self.entry_wt and
            self.entry_wt < -20 and  # Entered oversold
            self.wt1[0] > 20  # Now overbought
        )
        
        # Signal 8: MACD weakness
        macd_sell = (
            self.macd.macd[0] < self.macd.signal[0] and
            self.macd.macd[0] < self.macd.macd[-1] and
            self.wt1[0] > 0
        )
        
        # Fire sell signal
        if wt_sell:
            self.log('SELL: WT Overbought Cross Down')
            return True
        elif wt_cross_sell:
            self.log('SELL: WT Cross Down Above Zero')
            return True
        elif momentum_sell:
            self.log('SELL: Momentum Loss')
            return True
        elif quick_profit:
            self.log(f'SELL: Quick Profit {current_pnl:.2f}%')
            return True
        elif rsi_sell:
            self.log('SELL: RSI Overbought')
            return True
        elif time_exit:
            self.log(f'SELL: Time Exit with {current_pnl:.2f}% profit')
            return True
        elif wt_reversal:
            self.log('SELL: WT Full Reversal')
            return True
        elif macd_sell:
            self.log('SELL: MACD Weakness')
            return True
            
        return False
