"""
Bollinger Bands Mean Reversion Strategy
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy

class BollingerBandsStrategy(BaseStrategy):
    """Bollinger Bands with squeeze detection and volume confirmation"""
    
    strategy_name = "Bollinger Bands Pro"
    
    params = (
        ('bb_period', 20),
        ('bb_dev', 2.0),
        ('squeeze_threshold', 0.02),  # Bandwidth squeeze threshold
        ('volume_factor', 1.5),  # Volume must be this times average
        ('exit_at_middle', True),  # Exit at middle band
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 1),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Bollinger Bands
        self.bbands = bt.indicators.BollingerBands(
            self.dataclose,
            period=self.params.bb_period,
            devfactor=self.params.bb_dev
        )
        
        # Bandwidth (measure of volatility)
        self.bandwidth = (self.bbands.top - self.bbands.bot) / self.bbands.mid
        
        # Volume indicators
        self.volume = self.datas[0].volume
        self.volume_sma = bt.indicators.SMA(self.volume, period=20)
        
        # RSI for additional confirmation
        self.rsi = bt.indicators.RSI(self.dataclose, period=14)
        
    def buy_signal(self):
        """Buy when price touches lower band with volume confirmation"""
        return (self.dataclose[0] <= self.bbands.bot[0] and
                self.volume[0] > self.volume_sma[0] * self.params.volume_factor and
                self.rsi[0] < 40)  # Oversold confirmation
    
    def sell_signal(self):
        """Sell based on exit strategy"""
        if self.params.exit_at_middle:
            # Exit when price reaches middle band (quicker profits)
            return self.dataclose[0] >= self.bbands.mid[0]
        else:
            # Exit when price reaches upper band (larger profits but riskier)
            return self.dataclose[0] >= self.bbands.top[0]
