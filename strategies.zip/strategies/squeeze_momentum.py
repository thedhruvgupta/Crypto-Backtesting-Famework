"""
Squeeze Momentum Strategy (TTM Squeeze)
Bollinger Bands and Keltner Channel squeeze detection
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class SqueezeMomentumStrategy(BaseStrategy):
    """TTM Squeeze - Volatility compression and expansion trading"""
    
    strategy_name = "Squeeze Momentum"
    
    params = (
        # Bollinger Bands
        ('bb_period', 20),
        ('bb_mult', 2.0),
        
        # Keltner Channel
        ('kc_period', 20),
        ('kc_mult', 1.5),
        
        # Momentum
        ('mom_period', 12),
        ('mom_smooth', 6),
        
        # Signal settings
        ('min_squeeze_bars', 3),  # Minimum bars in squeeze
        ('momentum_threshold', 0),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 2.5),
        ('leverage', 10),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Bollinger Bands
        self.bb = bt.indicators.BollingerBands(
            self.dataclose,
            period=self.params.bb_period,
            devfactor=self.params.bb_mult
        )
        
        # Keltner Channel
        self.ema = bt.indicators.EMA(self.dataclose, period=self.params.kc_period)
        self.atr = bt.indicators.ATR(self.datas[0], period=self.params.kc_period)
        
        self.kc_upper = self.ema + (self.atr * self.params.kc_mult)
        self.kc_lower = self.ema - (self.atr * self.params.kc_mult)
        
        # Squeeze detection (BB inside KC)
        self.squeeze_on = bt.And(
            self.bb.lines.top < self.kc_upper,
            self.bb.lines.bot > self.kc_lower
        )
        
        # Linear Regression for momentum
        self.highest = bt.indicators.Highest(self.datahigh, period=self.params.mom_period)
        self.lowest = bt.indicators.Lowest(self.datalow, period=self.params.mom_period)
        self.avg_hl = (self.highest + self.lowest) / 2
        self.avg_close = bt.indicators.SMA(self.dataclose, period=self.params.mom_period)
        
        # Momentum oscillator
        self.mom_osc = self.dataclose - self.avg_hl
        self.momentum = bt.indicators.SMA(self.mom_osc, period=self.params.mom_smooth)
        
        # Momentum direction
        self.mom_increasing = self.momentum > self.momentum(-1)
        self.mom_decreasing = self.momentum < self.momentum(-1)
        
        # Track squeeze state
        self.squeeze_bars = 0
        self.was_in_squeeze = False
        self.squeeze_released = False
        
        # Additional indicators
        self.rsi = bt.indicators.RSI(self.dataclose, period=14)
        self.volume_sma = bt.indicators.SMA(self.datas[0].volume, period=20)
        
        # Track momentum histogram
        self.mom_hist = []
        
    def update_squeeze_state(self):
        """Track squeeze state and count bars"""
        
        current_squeeze = bool(self.squeeze_on[0])
        
        if current_squeeze:
            self.squeeze_bars += 1
            self.was_in_squeeze = True
            self.squeeze_released = False
        else:
            if self.was_in_squeeze:
                # Squeeze just released
                self.squeeze_released = True
                self.was_in_squeeze = False
            else:
                self.squeeze_released = False
            self.squeeze_bars = 0
        
        # Track momentum histogram colors
        if self.momentum[0] > 0:
            if self.momentum[0] > self.momentum[-1]:
                color = 'lime'  # Increasing positive
            else:
                color = 'green'  # Decreasing positive
        else:
            if self.momentum[0] < self.momentum[-1]:
                color = 'red'  # Decreasing negative
            else:
                color = 'maroon'  # Increasing negative
        
        self.mom_hist.append({
            'value': self.momentum[0],
            'color': color
        })
        
        # Keep only recent history
        if len(self.mom_hist) > 50:
            self.mom_hist.pop(0)
    
    def count_momentum_bars(self, color):
        """Count consecutive bars of same momentum color"""
        count = 0
        for hist in reversed(self.mom_hist):
            if hist['color'] == color:
                count += 1
            else:
                break
        return count
    
    def buy_signal(self):
        """Buy signals based on squeeze momentum"""
        
        self.update_squeeze_state()
        
        # Signal 1: Squeeze release with positive momentum
        squeeze_release_buy = (
            self.squeeze_released and
            self.squeeze_bars >= self.params.min_squeeze_bars and
            self.momentum[0] > self.params.momentum_threshold and
            self.mom_increasing[0]
        )
        
        if squeeze_release_buy:
            self.log(f'BUY: Squeeze release after {self.squeeze_bars} bars')
            return True
        
        # Signal 2: Momentum shift from red to green
        if len(self.mom_hist) >= 2:
            prev_color = self.mom_hist[-2]['color']
            curr_color = self.mom_hist[-1]['color']
            
            momentum_shift = (
                prev_color in ['red', 'maroon'] and
                curr_color in ['lime', 'green'] and
                self.momentum[0] > self.params.momentum_threshold
            )
            
            if momentum_shift:
                self.log('BUY: Momentum shift to positive')
                return True
        
        # Signal 3: Strong momentum continuation
        lime_bars = self.count_momentum_bars('lime')
        if lime_bars >= 2 and self.momentum[0] > self.momentum[-1] * 1.1:
            self.log('BUY: Strong momentum continuation')
            return True
        
        # Signal 4: Squeeze building with oversold
        if self.squeeze_bars >= 5 and self.rsi[0] < 35:
            self.log('BUY: Extended squeeze with RSI oversold')
            return True
        
        # Signal 5: No squeeze with strong momentum
        no_squeeze_momentum = (
            not self.squeeze_on[0] and
            self.momentum[0] > self.params.momentum_threshold and
            self.mom_increasing[0] and
            self.dataclose[0] > self.ema[0]
        )
        
        if no_squeeze_momentum and self.volume[0] > self.volume_sma[0]:
            self.log('BUY: Strong momentum without squeeze')
            return True
        
        return False
    
    def sell_signal(self):
        """Sell signals based on squeeze momentum"""
        
        if not self.position:
            return False
        
        self.update_squeeze_state()
        
        # Calculate current P/L
        if self.entry_price:
            current_pnl = ((self.dataclose[0] - self.entry_price) / self.entry_price) * 100
        else:
            current_pnl = 0
        
        # Signal 1: Momentum turning negative
        momentum_negative = (
            self.momentum[0] < -self.params.momentum_threshold and
            self.mom_decreasing[0]
        )
        
        if momentum_negative:
            self.log('SELL: Momentum turning negative')
            return True
        
        # Signal 2: Momentum shift from green to red
        if len(self.mom_hist) >= 2:
            prev_color = self.mom_hist[-2]['color']
            curr_color = self.mom_hist[-1]['color']
            
            momentum_shift = (
                prev_color in ['lime', 'green'] and
                curr_color in ['red', 'maroon']
            )
            
            if momentum_shift and current_pnl > 0:
                self.log('SELL: Momentum shift to negative')
                return True
        
        # Signal 3: Extended green turning dark green
        green_bars = self.count_momentum_bars('green')
        if green_bars >= 3 and self.momentum[0] < self.momentum[-1]:
            self.log('SELL: Momentum weakening')
            return True
        
        # Signal 4: Squeeze after expansion
        if self.squeeze_on[0] and not self.squeeze_on[-1] and current_pnl > 1:
            self.log('SELL: New squeeze forming')
            return True
        
        # Signal 5: RSI overbought with momentum decrease
        if self.rsi[0] > 70 and self.mom_decreasing[0]:
            self.log('SELL: RSI overbought with momentum decline')
            return True
        
        # Signal 6: Take profit on extended move
        red_bars = self.count_momentum_bars('red')
        if red_bars >= 2 or current_pnl > self.params.take_profit_pct:
            self.log(f'SELL: Take profit at {current_pnl:.2f}%')
            return True
        
        return False
