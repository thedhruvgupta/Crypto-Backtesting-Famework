"""
LuxAlgo Signals Strategy
Premium trading signals with confirmation system
"""

import backtrader as bt
import sys
import os
import numpy as np

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class LuxAlgoSignalsStrategy(BaseStrategy):
    """LuxAlgo Signals - Premium confirmation signals"""
    
    strategy_name = "LuxAlgo Signals"
    
    params = (
        # Signal settings
        ('sensitivity', 5),  # 1-10 scale
        ('confirmation_bars', 2),
        
        # Exit settings
        ('exit_sensitivity', 7),
        ('use_trailing_exit', True),
        
        # Filters
        ('use_volume_filter', True),
        ('use_volatility_filter', True),
        ('volatility_threshold', 1.5),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 2.5),
        ('leverage', 8),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Price action
        self.price_change = self.dataclose - self.dataclose(-1)
        
        # Volatility
        self.atr = bt.indicators.ATR(self.datas[0], period=14)
        self.volatility = self.atr / self.dataclose * 100
        
        # Volume
        self.volume = self.datas[0].volume
        self.volume_sma = bt.indicators.SMA(self.volume, period=20)
        
        # Smart Money Flow
        self.money_flow_mult = ((self.dataclose - self.datalow) - (self.datahigh - self.dataclose)) / \
                              bt.If((self.datahigh - self.datalow) > 0, self.datahigh - self.datalow, 0.001)
        self.money_flow_volume = self.money_flow_mult * self.volume
        self.smart_money = bt.indicators.SMA(bt.indicators.CumSum(self.money_flow_volume), period=14)
        
        # Trend filters
        self.ema_fast = bt.indicators.EMA(self.dataclose, period=21)
        self.ema_mid = bt.indicators.EMA(self.dataclose, period=50)
        self.ema_slow = bt.indicators.EMA(self.dataclose, period=200)
        
        # Signal oscillator
        self.signal_strength = self.calculate_signal_strength()
        
        # Confirmation system
        self.confirmations = []
        self.exit_signals = []
        
        # Support/Resistance
        self.recent_high = bt.indicators.Highest(self.datahigh, period=20)
        self.recent_low = bt.indicators.Lowest(self.datalow, period=20)
        
        # RSI
        self.rsi = bt.indicators.RSI(self.dataclose, period=14)
        
        # MACD
        self.macd = bt.indicators.MACD(self.dataclose)
        
        # Trailing stop tracking
        self.highest_price_since_entry = None
        self.lowest_price_since_entry = None
        
    def calculate_signal_strength(self):
        """Calculate LuxAlgo signal strength"""
        
        # Component 1: Price momentum
        momentum = bt.indicators.Momentum(self.dataclose, period=10)
        
        # Component 2: Volume pressure
        volume_pressure = self.volume / bt.If(self.volume_sma > 0, self.volume_sma, 1)
        
        # Component 3: Volatility state
        volatility_state = self.atr / bt.indicators.SMA(self.atr, period=50)
        
        # Component 4: Trend alignment
        trend_score = bt.If(self.dataclose > self.ema_fast, 1, -1) + \
                     bt.If(self.dataclose > self.ema_mid, 1, -1) + \
                     bt.If(self.dataclose > self.ema_slow, 1, -1)
        
        # Composite signal strength
        signal_strength = (momentum - 100) * volume_pressure * volatility_state * trend_score / 100
        
        return signal_strength
    
    def check_confirmations(self, signal_type='buy'):
        """Check for signal confirmations"""
        
        confirmations = 0
        
        if signal_type == 'buy':
            # Confirmation 1: Price action
            if self.dataclose[0] > self.dataopen[0]:  # Bullish candle
                confirmations += 1
            
            # Confirmation 2: Volume
            if self.params.use_volume_filter and self.volume[0] > self.volume_sma[0]:
                confirmations += 1
            
            # Confirmation 3: Smart money
            if self.smart_money[0] > self.smart_money[-1]:
                confirmations += 1
            
            # Confirmation 4: Trend
            if self.dataclose[0] > self.ema_fast[0]:
                confirmations += 1
            
            # Confirmation 5: RSI
            if self.rsi[0] > 40 and self.rsi[0] < 70:
                confirmations += 1
            
            # Confirmation 6: MACD
            if self.macd.macd[0] > self.macd.signal[0]:
                confirmations += 1
                
        else:  # sell
            # Confirmation 1: Price action
            if self.dataclose[0] < self.dataopen[0]:  # Bearish candle
                confirmations += 1
            
            # Confirmation 2: Volume
            if self.params.use_volume_filter and self.volume[0] > self.volume_sma[0] * 0.8:
                confirmations += 1
            
            # Confirmation 3: Smart money
            if self.smart_money[0] < self.smart_money[-1]:
                confirmations += 1
            
            # Confirmation 4: Trend
            if self.dataclose[0] < self.ema_fast[0]:
                confirmations += 1
            
            # Confirmation 5: RSI
            if self.rsi[0] < 60 or self.rsi[0] > 70:
                confirmations += 1
            
            # Confirmation 6: MACD
            if self.macd.macd[0] < self.macd.signal[0]:
                confirmations += 1
        
        return confirmations
    
    def detect_lux_buy_signal(self):
        """Detect LuxAlgo buy signal"""
        
        # Base conditions
        near_support = abs(self.dataclose[0] - self.recent_low[0]) / self.recent_low[0] < 0.01
        uptrend = self.ema_fast[0] > self.ema_mid[0]
        
        # Signal strength threshold
        sensitivity_adjusted = (11 - self.params.sensitivity) * 0.5
        signal_threshold = sensitivity_adjusted
        
        # Check signal strength
        strong_signal = self.signal_strength[0] > signal_threshold
        
        # Volatility filter
        if self.params.use_volatility_filter:
            volatility_ok = self.volatility[0] > self.params.volatility_threshold
        else:
            volatility_ok = True
        
        # Generate signal
        if strong_signal and volatility_ok:
            confirmations = self.check_confirmations('buy')
            if confirmations >= self.params.confirmation_bars:
                return True
        
        # Alternative signal: Bounce from support
        if near_support and uptrend and self.volume[0] > self.volume_sma[0]:
            return True
        
        # Alternative signal: Trend continuation
        if self.dataclose[0] > self.ema_fast[0] and self.ema_fast[0] > self.ema_fast[-1]:
            if self.rsi[0] > 50 and self.rsi[0] < 65:
                return True
        
        return False
    
    def detect_lux_sell_signal(self):
        """Detect LuxAlgo sell signal"""
        
        if not self.position:
            return False
        
        # Update trailing stops
        if self.params.use_trailing_exit:
            if self.highest_price_since_entry is None:
                self.highest_price_since_entry = self.dataclose[0]
            else:
                self.highest_price_since_entry = max(self.highest_price_since_entry, self.dataclose[0])
            
            # Trailing stop trigger
            trail_distance = (self.highest_price_since_entry - self.dataclose[0]) / self.highest_price_since_entry
            if trail_distance > 0.02:  # 2% trailing stop
                return True
        
        # Base conditions
        near_resistance = abs(self.dataclose[0] - self.recent_high[0]) / self.recent_high[0] < 0.01
        downtrend = self.ema_fast[0] < self.ema_mid[0]
        
        # Exit signal strength
        sensitivity_adjusted = (11 - self.params.exit_sensitivity) * 0.5
        signal_threshold = -sensitivity_adjusted
        
        # Check signal strength
        weak_signal = self.signal_strength[0] < signal_threshold
        
        # Generate exit signal
        if weak_signal:
            confirmations = self.check_confirmations('sell')
            if confirmations >= self.params.confirmation_bars:
                return True
        
        # Alternative exit: Resistance rejection
        if near_resistance and self.dataclose[0] < self.dataopen[0]:
            return True
        
        # Alternative exit: Trend reversal
        if self.dataclose[0] < self.ema_fast[0] and self.ema_fast[0] < self.ema_fast[-1]:
            if self.rsi[0] < 50 or self.rsi[0] > 70:
                return True
        
        return False
    
    def buy_signal(self):
        """Generate LuxAlgo buy signal"""
        
        if self.detect_lux_buy_signal():
            self.log('BUY: LuxAlgo Signal Triggered')
            self.highest_price_since_entry = None
            return True
        
        return False
    
    def sell_signal(self):
        """Generate LuxAlgo sell signal"""
        
        if self.detect_lux_sell_signal():
            self.log('SELL: LuxAlgo Exit Signal')
            self.highest_price_since_entry = None
            return True
        
        return False
