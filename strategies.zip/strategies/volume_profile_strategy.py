"""
Volume Profile Strategy
Trade based on volume analysis and support/resistance
"""

import backtrader as bt
import sys
import os

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy

class VolumeProfileStrategy(BaseStrategy):
    """Volume-based trading with support/resistance levels"""
    
    strategy_name = "Volume Profile"
    
    params = (
        ('volume_period', 20),
        ('volume_multiplier', 1.5),  # Volume spike threshold
        ('poc_period', 50),  # Point of Control period
        ('vwap_period', 20),
        ('rsi_period', 14),
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 5),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Volume indicators
        self.volume = self.datas[0].volume
        self.volume_sma = bt.indicators.SMA(self.volume, period=self.params.volume_period)
        
        # VWAP (Volume Weighted Average Price) approximation
        typical_price = (self.datahigh + self.datalow + self.dataclose) / 3
        self.vwap = bt.indicators.WeightedAverage(typical_price, self.volume, period=self.params.vwap_period)
        
        # RSI for momentum confirmation
        self.rsi = bt.indicators.RSI(self.dataclose, period=self.params.rsi_period)
        
        # Price levels
        self.resistance = bt.indicators.Highest(self.datahigh, period=self.params.poc_period)
        self.support = bt.indicators.Lowest(self.datalow, period=self.params.poc_period)
        
        # Volume-Price trend
        self.obv = bt.indicators.OnBalanceVolume(self.datas[0])
        self.obv_sma = bt.indicators.SMA(self.obv, period=10)
        
        # Accumulation/Distribution Line
        money_flow_multiplier = ((self.dataclose - self.datalow) - (self.datahigh - self.dataclose)) / (self.datahigh - self.datalow)
        money_flow_volume = money_flow_multiplier * self.volume
        self.ad_line = bt.indicators.CumSum(money_flow_volume)
        
    def buy_signal(self):
        """Buy on volume breakout with price confirmation"""
        # Volume spike
        volume_spike = self.volume[0] > self.volume_sma[0] * self.params.volume_multiplier
        
        # Price above VWAP (bullish)
        price_above_vwap = self.dataclose[0] > self.vwap[0]
        
        # Near support level
        near_support = abs(self.dataclose[0] - self.support[0]) / self.support[0] < 0.02
        
        # OBV trending up
        obv_bullish = self.obv[0] > self.obv_sma[0]
        
        # RSI not overbought
        rsi_room = self.rsi[0] < 70
        
        return ((volume_spike and price_above_vwap and rsi_room) or
                (near_support and obv_bullish and self.rsi[0] < 40))
    
    def sell_signal(self):
        """Sell on volume climax or resistance"""
        # Volume spike at resistance
        volume_spike = self.volume[0] > self.volume_sma[0] * self.params.volume_multiplier * 1.5
        
        # Near resistance level
        near_resistance = abs(self.dataclose[0] - self.resistance[0]) / self.resistance[0] < 0.01
        
        # Price below VWAP (bearish)
        price_below_vwap = self.dataclose[0] < self.vwap[0]
        
        # OBV trending down
        obv_bearish = self.obv[0] < self.obv_sma[0]
        
        # AD line divergence (price up but AD down)
        ad_divergence = self.ad_line[0] < self.ad_line[-5]
        
        return ((volume_spike and near_resistance) or
                (price_below_vwap and obv_bearish) or
                (self.rsi[0] > 75 and ad_divergence))
