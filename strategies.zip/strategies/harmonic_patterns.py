"""
Harmonic Pattern Strategy
Advanced pattern recognition: Gartley, Butterfly, Bat, Crab
"""

import backtrader as bt
import sys
import os
import math

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from base_strategy import BaseStrategy


class HarmonicPatternStrategy(BaseStrategy):
    """Harmonic Pattern - Fibonacci-based pattern trading"""
    
    strategy_name = "Harmonic Patterns"
    
    params = (
        # Pattern detection
        ('min_pattern_bars', 5),
        ('max_pattern_bars', 50),
        ('fib_tolerance', 0.05),  # 5% tolerance on Fibonacci levels
        
        # Pattern types to trade
        ('trade_gartley', True),
        ('trade_butterfly', True),
        ('trade_bat', True),
        ('trade_crab', True),
        
        # Confirmation
        ('use_rsi_confirm', True),
        ('use_volume_confirm', True),
        
        # Risk management
        ('printlog', False),
        ('risk_per_trade', 2.0),
        ('leverage', 6),
        ('stop_loss_pct', 2.0),
        ('take_profit_pct', 6.0),
        ('use_risk_management', True),
    )
    
    def __init__(self):
        super().__init__()
        
        # Price pivots
        self.pivots = []
        self.patterns = []
        
        # Indicators for confirmation
        self.rsi = bt.indicators.RSI(self.dataclose, period=14)
        self.volume_sma = bt.indicators.SMA(self.datas[0].volume, period=20)
        
        # Trend filter
        self.ema_trend = bt.indicators.EMA(self.dataclose, period=50)
        
        # ATR for targets
        self.atr = bt.indicators.ATR(self.datas[0], period=14)
        
        # Fibonacci levels
        self.fib_levels = {
            'gartley': {
                'XB': 0.618,
                'AC': (0.382, 0.886),
                'BD': (1.272, 1.618),
                'XD': 0.786
            },
            'butterfly': {
                'XB': 0.786,
                'AC': (0.382, 0.886),
                'BD': (1.618, 2.618),
                'XD': (1.27, 1.618)
            },
            'bat': {
                'XB': (0.382, 0.50),
                'AC': (0.382, 0.886),
                'BD': (1.618, 2.618),
                'XD': 0.886
            },
            'crab': {
                'XB': (0.382, 0.618),
                'AC': (0.382, 0.886),
                'BD': (2.24, 3.618),
                'XD': 1.618
            }
        }
        
        # Track active pattern
        self.active_pattern = None
        
    def identify_pivots(self):
        """Identify price pivots (swing highs and lows)"""
        
        if len(self) < 5:
            return
        
        # Check for swing high
        if (self.datahigh[-2] > self.datahigh[-3] and 
            self.datahigh[-2] > self.datahigh[-1] and
            self.datahigh[-2] > self.datahigh[-4] and
            self.datahigh[-2] > self.datahigh[0]):
            
            pivot = {
                'type': 'high',
                'price': self.datahigh[-2],
                'index': len(self) - 2
            }
            self.pivots.append(pivot)
        
        # Check for swing low
        if (self.datalow[-2] < self.datalow[-3] and
            self.datalow[-2] < self.datalow[-1] and
            self.datalow[-2] < self.datalow[-4] and
            self.datalow[-2] < self.datalow[0]):
            
            pivot = {
                'type': 'low',
                'price': self.datalow[-2],
                'index': len(self) - 2
            }
            self.pivots.append(pivot)
        
        # Keep only recent pivots
        if len(self.pivots) > 20:
            self.pivots.pop(0)
    
    def check_fibonacci_ratio(self, price1, price2, target_ratio, tolerance=None):
        """Check if price move matches Fibonacci ratio"""
        
        if tolerance is None:
            tolerance = self.params.fib_tolerance
        
        actual_ratio = abs(price2 - price1) / abs(price1) if price1 != 0 else 0
        
        if isinstance(target_ratio, tuple):
            return target_ratio[0] * (1 - tolerance) <= actual_ratio <= target_ratio[1] * (1 + tolerance)
        else:
            return abs(actual_ratio - target_ratio) / target_ratio <= tolerance
    
    def find_harmonic_patterns(self):
        """Find harmonic patterns in recent pivots"""
        
        if len(self.pivots) < 5:
            return None
        
        # Get last 5 pivots for XABCD pattern
        for i in range(len(self.pivots) - 4):
            X = self.pivots[i]
            A = self.pivots[i + 1]
            B = self.pivots[i + 2]
            C = self.pivots[i + 3]
            D = self.pivots[i + 4]
            
            # Ensure correct pivot sequence (alternating highs/lows)
            if not (X['type'] != A['type'] != B['type'] != C['type'] != D['type']):
                continue
            
            # Check if pattern is within time range
            if D['index'] - X['index'] > self.params.max_pattern_bars:
                continue
            
            # Determine if bullish or bearish pattern
            if X['type'] == 'low':
                # Potential bullish pattern
                pattern_type = self.check_bullish_pattern(X, A, B, C, D)
            else:
                # Potential bearish pattern
                pattern_type = self.check_bearish_pattern(X, A, B, C, D)
            
            if pattern_type:
                return {
                    'type': pattern_type,
                    'direction': 'bullish' if X['type'] == 'low' else 'bearish',
                    'X': X,
                    'A': A,
                    'B': B,
                    'C': C,
                    'D': D,
                    'completion': D['price']
                }
        
        return None
    
    def check_bullish_pattern(self, X, A, B, C, D):
        """Check for bullish harmonic patterns"""
        
        XA = A['price'] - X['price']
        AB = B['price'] - A['price']
        BC = C['price'] - B['price']
        CD = D['price'] - C['price']
        XD = D['price'] - X['price']
        
        # Gartley
        if self.params.trade_gartley:
            if (self.check_fibonacci_ratio(AB, XA, self.fib_levels['gartley']['XB']) and
                self.check_fibonacci_ratio(BC, AB, self.fib_levels['gartley']['AC']) and
                self.check_fibonacci_ratio(CD, BC, self.fib_levels['gartley']['BD']) and
                self.check_fibonacci_ratio(XD, XA, self.fib_levels['gartley']['XD'])):
                return 'gartley'
        
        # Butterfly
        if self.params.trade_butterfly:
            if (self.check_fibonacci_ratio(AB, XA, self.fib_levels['butterfly']['XB']) and
                self.check_fibonacci_ratio(BC, AB, self.fib_levels['butterfly']['AC']) and
                self.check_fibonacci_ratio(CD, BC, self.fib_levels['butterfly']['BD'])):
                return 'butterfly'
        
        # Bat
        if self.params.trade_bat:
            if (self.check_fibonacci_ratio(AB, XA, self.fib_levels['bat']['XB']) and
                self.check_fibonacci_ratio(BC, AB, self.fib_levels['bat']['AC']) and
                self.check_fibonacci_ratio(XD, XA, self.fib_levels['bat']['XD'])):
                return 'bat'
        
        # Crab
        if self.params.trade_crab:
            if (self.check_fibonacci_ratio(AB, XA, self.fib_levels['crab']['XB']) and
                self.check_fibonacci_ratio(BC, AB, self.fib_levels['crab']['AC']) and
                self.check_fibonacci_ratio(XD, XA, self.fib_levels['crab']['XD'])):
                return 'crab'
        
        return None
    
    def check_bearish_pattern(self, X, A, B, C, D):
        """Check for bearish harmonic patterns"""
        
        XA = X['price'] - A['price']
        AB = A['price'] - B['price']
        BC = B['price'] - C['price']
        CD = C['price'] - D['price']
        XD = X['price'] - D['price']
        
        # Similar checks but for bearish patterns
        # (Implementation similar to bullish but with inverted logic)
        
        return None
    
    def confirm_pattern_signal(self, pattern):
        """Confirm harmonic pattern with additional indicators"""
        
        confirmations = 0
        
        if pattern['direction'] == 'bullish':
            # RSI confirmation
            if self.params.use_rsi_confirm and self.rsi[0] < 40:
                confirmations += 1
            
            # Volume confirmation
            if self.params.use_volume_confirm and self.volume[0] > self.volume_sma[0]:
                confirmations += 1
            
            # Price at pattern completion
            if abs(self.dataclose[0] - pattern['D']['price']) / pattern['D']['price'] < 0.01:
                confirmations += 1
        
        else:  # bearish
            # RSI confirmation
            if self.params.use_rsi_confirm and self.rsi[0] > 60:
                confirmations += 1
            
            # Volume confirmation
            if self.params.use_volume_confirm and self.volume[0] > self.volume_sma[0]:
                confirmations += 1
            
            # Price at pattern completion
            if abs(self.dataclose[0] - pattern['D']['price']) / pattern['D']['price'] < 0.01:
                confirmations += 1
        
        return confirmations >= 2
    
    def buy_signal(self):
        """Generate buy signals from harmonic patterns"""
        
        # Update pivots
        self.identify_pivots()
        
        # Find patterns
        pattern = self.find_harmonic_patterns()
        
        if pattern and pattern['direction'] == 'bullish':
            # Check if pattern just completed
            if len(self) - pattern['D']['index'] < 5:
                if self.confirm_pattern_signal(pattern):
                    self.active_pattern = pattern
                    self.log(f"BUY: {pattern['type'].upper()} Pattern Completed")
                    return True
        
        # Alternative: Simple pivot reversal
        if len(self.pivots) >= 2:
            last_pivot = self.pivots[-1]
            if (last_pivot['type'] == 'low' and 
                len(self) - last_pivot['index'] < 3 and
                self.dataclose[0] > last_pivot['price'] * 1.005):
                
                if self.rsi[0] < 35:
                    self.log('BUY: Pivot Low Reversal')
                    return True
        
        return False
    
    def sell_signal(self):
        """Generate sell signals from harmonic patterns"""
        
        if not self.position:
            return False
        
        # Check if pattern target reached
        if self.active_pattern:
            if self.active_pattern['direction'] == 'bullish':
                # Calculate pattern targets
                pattern_range = self.active_pattern['A']['price'] - self.active_pattern['D']['price']
                target1 = self.active_pattern['D']['price'] + (pattern_range * 0.382)
                target2 = self.active_pattern['D']['price'] + (pattern_range * 0.618)
                
                if self.dataclose[0] >= target1:
                    self.log('SELL: Pattern Target 1 Reached')
                    self.active_pattern = None
                    return True
        
        # Find bearish patterns
        pattern = self.find_harmonic_patterns()
        
        if pattern and pattern['direction'] == 'bearish':
            if len(self) - pattern['D']['index'] < 5:
                if self.confirm_pattern_signal(pattern):
                    self.log(f"SELL: {pattern['type'].upper()} Pattern Completed")
                    return True
        
        # Alternative: Pivot high reversal
        if len(self.pivots) >= 2:
            last_pivot = self.pivots[-1]
            if (last_pivot['type'] == 'high' and
                len(self) - last_pivot['index'] < 3 and
                self.dataclose[0] < last_pivot['price'] * 0.995):
                
                if self.rsi[0] > 65:
                    self.log('SELL: Pivot High Reversal')
                    return True
        
        return False
